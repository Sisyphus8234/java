package cn.tedu.controller;

import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import javax.crypto.spec.PSource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;
import java.util.HashMap;

@RestController
@RequestMapping("/home")
public class HomeController {
    //显示登录页面的方法
    @GetMapping("/login.do")
    //localhost:8080/home/login.do
    public ModelAndView showLogin(){

        return new ModelAndView("login");
    }
    //接收表单提交的登录信息判断登录结果,并返回信息
    // 由于我们要使用request对象传递信息,所以需要声明它
    //@PostMapping("/handle_login.do")
    public ModelAndView handleLogin(
            String username, String password,
            HttpServletRequest request){
        //使用request.setAttribute()方法向页面传递信息
        //setAttribute(key,value)页面上出现的th:标签指定的内容
        //会对应setAttribute方法中的key,显示这个key对应的value
        if("tom".equals(username)){
            if("123".equals(password)){
                request.setAttribute("message","登录成功");
                return new ModelAndView("message");
            }else{
                request.setAttribute("message","密码错误");
                return new ModelAndView("message");
            }
        }else{
            //传递信息:message指的是页面中th:text指定的key
            request.setAttribute("message","用户名错误");
            //返回视图:这里的message指定的是message.html页面
            return new ModelAndView("message");
        }

    }
    //使用ModelAndView传递信息的方法
    //@PostMapping("/handle_login.do")
    public ModelAndView handleLogin(
            String username,String password){

        if("tom".equals(username)){
            if("123".equals(password)){
                ModelAndView mv=new ModelAndView("message");
                mv.addObject("message","登录成功");
                return mv;
            }else{
                ModelAndView mv=new ModelAndView("message");
                mv.addObject("message","密码错误");
                return mv;
            }
        }else{
            //使用ModelAndView对象的addObject方法添加信息
            //信息格式也是键值对
            ModelAndView mv=new ModelAndView("message");
            mv.addObject("message","用户名错误");
            return mv;
        }

    }

    //使用ModelMap传递信息的方法
    @PostMapping("/handle_login.do")
    public ModelAndView handleLogin(
            String username, String password, ModelMap map,
            HttpSession session){
        //方法的参数中声明session对象
        //DispatcherServlet就会自动将当前会话对象赋值到这个session中
        if("tom".equals(username)){
            if("123".equals(password)){
                map.put("message","登录成功");
                //登录成功,将用户保存在Session中
                session.setAttribute("user",username);
                return  new ModelAndView("message");
            }else{
                map.put("message","密码错误");
                return  new ModelAndView("message");
            }
        }else{
            map.put("message","用户名错误");
            return  new ModelAndView("message");
        }
    }

    //显示已登录用户名的页面
    @GetMapping("/show_name.do")
    public ModelAndView showName(
            HttpSession session,ModelMap map){
        //先从session中获得用户名
        String username=(String)session.getAttribute("user");
        //再将获得的用户名赋值到ModelMap中用于显示在页面上
        map.put("username",username);
        //转发到视图
        return new ModelAndView("welcome");
    }









}
