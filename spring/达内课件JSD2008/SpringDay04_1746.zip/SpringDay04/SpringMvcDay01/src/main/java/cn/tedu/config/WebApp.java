package cn.tedu.config;

import org.springframework.web.filter.CharacterEncodingFilter;
import org.springframework.web.servlet.support.AbstractAnnotationConfigDispatcherServletInitializer;

import javax.servlet.Filter;

//AbstractAnnotationConfigDispatcherServletInitializer
//是SpringMVC提供的,它包含几个必须由我们重写并配置SpringMvc运行信息的方法

public class WebApp extends
        AbstractAnnotationConfigDispatcherServletInitializer {
    // 继承的这个抽象类有一个特征
    // tomcat一旦启动就会自动运行下面的三个方法

    //RootConfig配置和控制器无关的Spring配置类
    @Override
    protected Class<?>[] getRootConfigClasses() {
        System.out.println("111111");
        return new Class[0];
    }
    //ServletConfig配置和控制器相关的Spring配置类
    @Override
    protected Class<?>[] getServletConfigClasses() {
        System.out.println("222222");
        return new Class[]{SpringMvcConfig.class};
    }
    //getServletMappings是指定SpringMvc对什么样的请求进行处理的方法
    //配置*.do 表示所有以.do结尾的请求,都会交由SpringMvc处理
    @Override
    protected String[] getServletMappings() {
        System.out.println("333333");
        return new String[]{"*.do"};
    }

    //这个方法不是必须重写的
    //但是表单提交中文有乱码
    //添加一个过滤器防止乱码的出现
    @Override
    protected Filter[] getServletFilters() {
        return new Filter[]{new CharacterEncodingFilter("UTF-8")};
    }
}
