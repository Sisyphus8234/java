package cn.tedu.config;

import cn.tedu.interceptor.AccessInterceptor;
import cn.tedu.interceptor.DemoInterceptor;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.web.servlet.config.annotation.EnableWebMvc;
import org.springframework.web.servlet.config.annotation.InterceptorRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurer;
import org.thymeleaf.spring5.SpringTemplateEngine;
import org.thymeleaf.spring5.view.ThymeleafViewResolver;
import org.thymeleaf.templatemode.TemplateMode;
import org.thymeleaf.templateresolver.ClassLoaderTemplateResolver;

@ComponentScan("cn.tedu.controller")
//@EnableWebMvc 表示当前配置类可以配置SpringMvc相关信息
//这里就是值可以配置拦截器
@EnableWebMvc
public class SpringMvcConfig implements WebMvcConfigurer {
    //上面实现的接口也是表示当前的SpringMvcConfig类是可以配置拦截器的

    //下面的方法就是专门注册拦截器到SpringMvc中的方法
    //参数InterceptorRegistry就是注册拦截器的对象
    @Override
    public void addInterceptors(InterceptorRegistry registry) {
        //注册一个拦截器,拦截/home/show_name.do
        //即当访问/home/show_name.do路径时执行这个拦截器
        registry.addInterceptor(new DemoInterceptor())
                .addPathPatterns("/home/show_name.do");
        //再注册一个拦截器
        registry.addInterceptor(new AccessInterceptor())
                .addPathPatterns(
                        "/home/show_name.do",
                        "/user/get.do",
                        "/doc/*",
                        "/cart/**")
                .excludePathPatterns(
                        "/doc/chong.do",
                        "/cart/add.do");

        /*
         /doc/* 的配置可以拦截 /doc/chong.do /doc/doc.do
         但是如果今后开发出现了类似   /doc/xxx/abc.do的多级目录
          /doc/*是不能拦截的
         只能使用/doc/** 这种写法 它可以拦截/doc/开头的所有请求
        */

    }

    @Bean
    public ThymeleafViewResolver viewResolver() {
        System.out.println("init ThymeleafViewResolver");

        //设置模板保存位置为 /resources/templates/*.html
        ClassLoaderTemplateResolver templateResolver =
                new ClassLoaderTemplateResolver();
        //模版存储文件夹
        templateResolver.setPrefix("/templates/");
        //模版后缀
        templateResolver.setSuffix(".html");
        templateResolver.setCharacterEncoding("UTF-8");
        templateResolver.setTemplateMode(TemplateMode.HTML);
        templateResolver.setCacheable(true);
        //创建模板引擎
        SpringTemplateEngine templateEngine =
                new SpringTemplateEngine();
        templateEngine.setTemplateResolver(templateResolver);
        templateEngine.setEnableSpringELCompiler(true);
        //创建模版解析器
        ThymeleafViewResolver viewResolver =
                new ThymeleafViewResolver();
        viewResolver.setCharacterEncoding("UTF-8");
        viewResolver.setTemplateEngine(templateEngine);
        return viewResolver;
    }
}
