package cn.tedu.controller;

import cn.tedu.vo.User;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;

//@RestController和@Controller的区别
//@RestController除了Controller注解的功能将当前类注入到Spring容器之外
//所有返回字符串的方法,都是直接将字符串返回相当于加了@ResponseBody
//如果想返回页面,直接返回ModelAndView对象即可
@RestController
//@RequestMapping()写在类上,表示要访问这个类中的方法,需要统一前置增加指定内容
//比如("/user") 就表示要想访问这个类中的方法需要先写"/user"
@RequestMapping("/user")
public class UserController {

    //@GetMapping("/abc.do")//localhost:8080/user/abc.do
    //...
    @GetMapping("/reg.do")//localhost:8080/user/reg.do
    public ModelAndView reg(){
        return new ModelAndView("reg");
    }

    @PostMapping("/handle_reg.do")
    public String handReg(User user, HttpServletRequest request){
        System.out.println(user);
        //输出客户端的ip地址
        System.out.println("访问服务器的客户端地址为:"+request.getRemoteAddr());
        return "OK";
    }

    //接收表单信息的方法
    //@PostMapping来接受post请求
    //@PostMapping("/handle_reg.do")
    public String handReg(
            String username,
            String password,
            int age,
            String phone,
            String email
    ){
        System.out.println("用户名:"+username);
        System.out.println("密码:"+password);
        System.out.println("年龄:"+age);
        System.out.println("电话:"+phone);
        System.out.println("电邮:"+email);
        return "OK";
    }

    //接收get请求参数的方法
    //@GetMapping("/get.do")
    //参数的参数名必须和?后面的名称一致
    public String getid(int id){
        System.out.println("id:"+id*1234);
        return  "ok";
    }


    @GetMapping("/get.do")
    //如果get请求参数名是特殊字符\java关键字name参数名称就无法直接对应
    //需要在参数前添加@RequestParam注解
    // 这个注解可以指定后门参数对象的get请求参数名
    public String get(@RequestParam("if") int num){
        System.out.println("num:"+num);
        return  "ok";
    }





}
