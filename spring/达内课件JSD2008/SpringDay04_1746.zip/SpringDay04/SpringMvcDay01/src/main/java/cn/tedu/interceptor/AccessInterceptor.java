package cn.tedu.interceptor;

import org.springframework.web.servlet.HandlerInterceptor;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.swing.*;

public class AccessInterceptor implements HandlerInterceptor {

    @Override
    public boolean preHandle(HttpServletRequest request,
                             HttpServletResponse response,
                             Object handler) throws Exception {
        HttpSession session = request.getSession();
        String username = (String) session.getAttribute("user");
        System.out.println("拦截器获得session中用户名为:" + username);
        //根据从session中获得的用户名决定当前请求是否可以继续访问目标控制器
        if (username == null || username.isEmpty()) {
            // 如果用户名是空,重定向到登录页
            //request.getContextPath()获得结果等价于
            //localhost:8080
            String path=request.getContextPath()
                    +"/home/login.do";
            response.sendRedirect(path);
            return false;
        }
        System.out.println("已经登录,放行!");
        return true;
    }
}
