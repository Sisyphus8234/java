package cn.tedu.controller;

import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

/**
 * 演示重定向的控制器
 */
@RestController
@RequestMapping("/doc")
public class DocController {

    //使用重定向跳转到其它网站
    @GetMapping("/doc.do")
    public ModelAndView doc(){
        System.out.println("重定向到苍老师的网站");
        return new ModelAndView(
                "redirect:http://doc.canglaoshi.org");
    }

    //使用重定向跳转其它控制器方法
    @GetMapping("/chong.do")
    public ModelAndView chong(){
        return new ModelAndView("redirect:../test.do");
    }







}
