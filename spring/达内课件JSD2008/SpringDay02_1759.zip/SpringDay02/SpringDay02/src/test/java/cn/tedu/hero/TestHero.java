package cn.tedu.hero;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TestHero {

    AnnotationConfigApplicationContext ctx;

    @Before
    public  void init(){
        ctx=new AnnotationConfigApplicationContext(Config.class);
        System.out.println("111111111111");
    }
    @After
    public void destroy(){
        ctx.close();
    }

    @Test
    public void fightTest(){
        Hero h=ctx.getBean("guanYu",Hero.class);
        h.fight();
    }







    @Test
    public void test(){

        System.out.println("222222222222222");
        Hero h=ctx.getBean("guanYu",Hero.class);
        System.out.println(h);
        Hero h1=ctx.getBean("guanYu",Hero.class);
        System.out.println(h1);

        DragonBlade d1=ctx.getBean("dragonBlade",DragonBlade.class);
        System.out.println(d1);

        DragonBlade d2=ctx.getBean("dragonBlade",DragonBlade.class);
        System.out.println(d2);




    }









}
