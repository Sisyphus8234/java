package cn.tedu.write;


import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TestWrite {

    AnnotationConfigApplicationContext ctx;

    @Before
    public  void init(){
        ctx=new AnnotationConfigApplicationContext(Config.class);
    }
    @After
    public void destroy(){
        ctx.close();
    }

    @Test
    public void writeTest(){
        Person p=ctx.getBean("person",Person.class);
        p.write();
    }







}
