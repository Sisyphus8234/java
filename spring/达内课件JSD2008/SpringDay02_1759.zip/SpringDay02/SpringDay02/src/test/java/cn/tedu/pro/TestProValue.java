package cn.tedu.pro;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

public class TestProValue {
    AnnotationConfigApplicationContext ctx;
    @Before
    public  void init(){
        ctx=new AnnotationConfigApplicationContext(ConfigValue.class);
    }
    @After
    public void destroy(){
        ctx.close();
    }

    @Test
    public void test() throws SQLException {
        DataSource ds=ctx.getBean("dataValue",DataSource.class);
        try(Connection conn=ds.getConnection()){
            String sql="select username from vrduser where id=4";
            PreparedStatement ps=conn.prepareStatement(sql);
            ResultSet rs=ps.executeQuery();
            while(rs.next()){
                System.out.println(rs.getString(1));
            }
        }
//        System.out.println(ds.getConnection());
//        System.out.println(ds);
    }




}
