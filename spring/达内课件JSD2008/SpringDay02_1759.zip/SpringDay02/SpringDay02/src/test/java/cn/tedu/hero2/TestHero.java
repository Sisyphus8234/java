package cn.tedu.hero2;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class TestHero {

    AnnotationConfigApplicationContext ctx;

    @Before
    public  void init(){
        ctx=new AnnotationConfigApplicationContext(Config.class);
    }
    @After
    public void destroy(){
        ctx.close();
    }

    @Test
    public void abc(){
        GuanYu gy=ctx.getBean("guanYu",GuanYu.class);
        gy.fight();
    }

}
