package cn.tedu.write;

import org.springframework.stereotype.Component;

@Component
public class Pencil implements WriteAble {

    private String name = "铅笔";

    public String toString() {
        return name;
    }

}
