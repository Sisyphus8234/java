package cn.tedu.hero2;

import org.springframework.stereotype.Component;

import java.io.Serializable;


public class DragonBlade implements Weapon, Serializable {

    private String name="青龙偃月刀";

    @Override
    public String toString() {
        return name;
    }
}
