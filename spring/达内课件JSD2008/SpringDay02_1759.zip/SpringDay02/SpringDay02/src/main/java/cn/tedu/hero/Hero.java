package cn.tedu.hero;

import java.io.Serializable;

public class Hero implements Serializable {

    private String name;
    private int age;

    private DragonBlade dragonBlade;

    public void fight(){

        System.out.println(name+"使用"+dragonBlade+"战斗");

    }

    public Hero(){
        System.out.println("Hero实例化!");
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public int getAge() {
        return age;
    }

    public void setAge(int age) {
        this.age = age;
    }

    public DragonBlade getDragonBlade() {
        return dragonBlade;
    }

    public void setDragonBlade(DragonBlade dragonBlade) {
        this.dragonBlade = dragonBlade;
    }

    @Override
    public String toString() {
        return "Hero{" +
                "name='" + name + '\'' +
                ", age=" + age +
                '}';
    }
}
