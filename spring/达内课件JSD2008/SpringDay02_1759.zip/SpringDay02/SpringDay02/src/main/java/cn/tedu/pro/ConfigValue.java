package cn.tedu.pro;

import com.alibaba.druid.pool.DruidDataSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

import javax.sql.DataSource;

@PropertySource("classpath:jdbc.properties")
public class ConfigValue {

    //这个方法无需自动装配Environment对象

    //@Value实际上会自动从@PropertySource指定的配置文件中获得信息
    //@Value("${}")  ${}中的内容是properties文件中的name(键)
    // 这个键对应的值会自动赋值到@Value注解之后的参数中!
    @Bean
    public DataSource dataValue(
            @Value("${db.driver}") String driver,
            @Value("${db.url}") String url,
            @Value("${db.username}") String username,
            @Value("${db.password}") String password,
            @Value("${db.maxActive}") int maxActive,
            @Value("${db.initialSize}") int initialSize
    ){
        DruidDataSource ds=new DruidDataSource();
        ds.setDriverClassName(driver);
        ds.setUrl(url);
        ds.setUsername(username);
        ds.setPassword(password);
        ds.setMaxActive(maxActive);
        ds.setInitialSize(initialSize);
        return ds;

    }




}
