package cn.tedu.hero;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Lazy;
import org.springframework.context.annotation.Scope;

@ComponentScan("cn.tedu.hero")
public class Config {

    //现在Spring容器中注入两把青龙偃月刀
    @Bean
    public DragonBlade blade1(){//id为blade1
        return new DragonBlade();
    }
    @Bean
    public DragonBlade blade2(){//id为blade2
        return new DragonBlade();
    }
    @Bean
    //方法的参数为DragonBlade类型
    //这个参数编写后,spring容器会自动从当前容器中所有内容中搜索
    //只要有DragonBlade类型的对象就会自动赋值到这个参数中
    //但是如果当前Spring容器中有两个或以上的DragonBlade对象
    //就需要按照DragonBlade对象的id来声明这个方法参数的属性名
    //如果方法参数的名称没有匹配任何Spring容器中的id,则会发生异常
    public Hero guanYu(DragonBlade blade2){
        Hero h=new Hero();
        h.setName("关羽");
        h.setAge(25);
        h.setDragonBlade(blade2);
        return h;
    }


}
