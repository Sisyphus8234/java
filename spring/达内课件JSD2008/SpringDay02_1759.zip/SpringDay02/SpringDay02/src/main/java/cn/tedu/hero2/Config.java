package cn.tedu.hero2;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;

@ComponentScan("cn.tedu.hero2")
public class Config {

    @Bean
    public DragonBlade db() {
        return new DragonBlade();
    }

    @Bean
    public SkyLancer lan(){
        return new SkyLancer();
    }


}
