package cn.tedu.write;

public interface WriteAble {

    public String toString();
}
