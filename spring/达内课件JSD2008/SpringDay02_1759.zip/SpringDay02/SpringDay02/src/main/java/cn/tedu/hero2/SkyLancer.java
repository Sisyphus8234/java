package cn.tedu.hero2;

import org.springframework.stereotype.Component;

import java.io.Serializable;


public class SkyLancer implements Weapon, Serializable {

    private String name="方天画戟";
    @Override
    public String toString() {
        return name;
    }
}
