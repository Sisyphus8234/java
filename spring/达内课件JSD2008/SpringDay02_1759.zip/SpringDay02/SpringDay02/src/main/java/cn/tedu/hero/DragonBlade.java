package cn.tedu.hero;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;


public class DragonBlade {

    private String name="青龙偃月刀";

    public DragonBlade(){
        System.out.println("DragonBlade实例化");
    }

    @Override
    public String toString() {
        return name;
    }
}
