package cn.tedu.hero2;

// 这是一个武器接口
public interface Weapon {

    //实现武器接口必须重写toString方法
    public String toString();

    //我们通过接口能够降低程序的耦合性
    //在依赖武器的对象中声明时,声明接口类型对象,而不声明具体类


}
