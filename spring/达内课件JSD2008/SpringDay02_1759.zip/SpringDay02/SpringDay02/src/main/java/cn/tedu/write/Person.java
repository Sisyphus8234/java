package cn.tedu.write;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.stereotype.Component;

@Component
public class Person {

    private String name="李白";

    @Autowired
    @Qualifier("pencil")
    private WriteAble writeAble;

    public void write(){
        System.out.println(name+"使用"+ writeAble+"写字");
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public WriteAble getWriteAble() {
        return writeAble;
    }

    public void setWriteAble(WriteAble writeAble) {
        this.writeAble = writeAble;
    }
}
