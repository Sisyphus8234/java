package cn.tedu.pro;

import com.alibaba.druid.pool.DruidDataSource;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.PropertySource;
import org.springframework.core.env.Environment;

import javax.sql.DataSource;

//指定配置文件的位置
//classpath实际上就是指resources文件夹
@PropertySource("classpath:jdbc.properties")
public class Config {

    //这个自动装配是Spring获取Spring中自带的Environment类型对象
    //这个对象会对@PropertySource声明的配置文件进行解析
    @Autowired
    Environment env;
    @Bean
    public DataSource dataEnv(){
        System.out.println(env);
        DruidDataSource ds=new DruidDataSource();
        //使用env对象为ds设置参数
        ds.setUrl(env.getProperty("db.url"));
        ds.setDriverClassName(env.getProperty("db.driver"));
        ds.setUsername(env.getProperty("db.username"));
        ds.setPassword(env.getProperty("db.password"));
        ds.setMaxActive(
                env.getProperty("db.maxActive",Integer.class));
        ds.setInitialSize(
                env.getProperty("db.initialSize",Integer.class));
        return ds;
    }

}
