package cn.tedu.write;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;

@ComponentScan("cn.tedu.write")
public class Config {

    /*@Bean
    public Pen pen(){
      return new Pen();
    }
    @Bean
    public Person person(Pen pen){
        Person p=new Person();
        p.setName("李白");
        p.setPen(pen);
        return p;
    }*/


}
