package cn.tedu.hero2;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Component;

import java.io.Serializable;

@Component
public class GuanYu implements Serializable {

    private String name="关羽";
    //@Autowired英文翻译为自动装配
    //表示这个注解下面声明的属性Spring会自动将合适的类型的对象赋给它使用
    //当前Spring容器中包含唯一匹配DragonBlade类型的对象,那么它会自动赋值
    // 为了实现解耦,我们声明为了Weapon接口
    // 这时自动装配任何实现了Weapon接口的类对象
    @Autowired
    // @Qualifier注解来决定Spring容器中具体id的对象注入到weapon属性中
    @Qualifier("aaa")//指定了id为dragonBlade的对象赋值到weapon属性中
    private Weapon weapon;
    //为了降低程序的耦合性,将原声明的具体类DragonBlade
    //修改为声明接口Weapon
    //private DragonBlade dragonBlade;

    public void fight(){

        System.out.println(name+"使用"+weapon+"战斗");
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Weapon getWeapon() {
        return weapon;
    }

    public void setWeapon(Weapon weapon) {
        this.weapon = weapon;
    }
}
