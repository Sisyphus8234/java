package cn.tedu.mapper;

import org.apache.ibatis.annotations.Select;

public interface DemoMapper {

    @Select("select username from vrduser where id=1")
    public String hello();

}
