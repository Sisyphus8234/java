package cn.tedu.mapper;

import cn.tedu.entity.User;
import org.apache.ibatis.annotations.*;

import java.util.List;

public interface UserMapper {

    @Select("select id,username,password,age,phone,email" +
            " from t_user where id=#{id}")
    User findUserById(Integer id);

    //Mybatis会自动根据接口方法定义的返回值类型
    //来返回查询结果
    @Select("select id,username,password,age,phone,email" +
            " from t_user")
    List<User> findAllUsers();

    //新增用户的方法
    //返回的Integer是受影响的行数 新增1行时 1行受影响表示成功
    @Insert("insert into t_user values" +
            "(null,#{username},#{password},#{age},#{phone},#{email})")
    Integer insertUser(User user);

    //下面的方法是新增用户并将新增后自增的id赋值给用户对象的属性
    @Insert("insert into t_user values" +
            "(null,#{username},#{password},#{age},#{phone},#{email})")
    //useGeneratedKeys表示获取生成的主键 true就是要获取
    //keyProperty表示获得的主键要赋给user的哪个属性
    @Options(useGeneratedKeys = true, keyProperty = "id")
    Integer insertUserWithId(User user);


    @Update("update t_user set username=#{username}," +
            "password=#{password},age=#{age},phone=#{phone}," +
            "email=#{email} where id=#{id}")
    Integer updateUser(User user);


    //按id修改email的方法
    @Update("update t_user set email=#{email} where id=#{id}")
    Integer updateEmailById(
            @Param("id") Integer id,
            @Param("email") String email);

    /*
    Mybatis框架接口中编写的方法如果有两个或以上的参数会出现问题
    因为默认情况下.java文件编译成.class文件后
    所有局部变量的名称都会丢失所以在运行时Mybatis不能根据给定的参数名称
    去对应sql语句中#{}中的内容
     */

    //按id删除用户
    @Delete("delete from t_user where id=#{id}")
    public Integer deleteById(Integer id);

//3.查询输出username为Frank13的用户信息
    @Select("select * from t_user where username=#{username}")
    User getUserByUsername(String username);

//4.查询输出age在22岁(包含)到28岁(包含)之间的用户信息
    @Select("select * from t_user where age between 22 and 28")
    List<User> getUsersByAge();


//5.查询输出username以F开头的用户的信息

    @Select("select * from t_user where username like #{username}")
    List<User> getUsersLikeName(String username);


}
