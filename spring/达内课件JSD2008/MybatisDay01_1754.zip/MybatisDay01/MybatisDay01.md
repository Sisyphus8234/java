# 拦截器和过滤器的区别

1.拦截器是SpringMvc框架的组件,而过滤器是java提供的API

2.拦截器只能拦截目标为DispatcherServlet的请求

   过滤器范围广,过滤目标可以是任何资源

3.功能上拦截器功能更强,和SpringMvc配合更方便

   过滤器只和javaEEAPI相关,功能稍弱

​        ![img](b3qz1Pgg4jMPHlqR.png!thumbnail)      

小结

如果实现http协议级别的基本拦截过滤,就使用过滤器

如果实现对SpringMvc控制器代码的拦截过滤,就使用拦截器



# MyBatis

# Mybatis简介

什么是Mybatis

是一个持久层框架,功能是简化之前我们学习的处理数据库连接的JDBC代码

早期叫Ibatis

我们称的SSM实际上就是Spring+SpringMvc+Mybatis的组合

SSI实际上就是SSM

## 配置Mybatis

步骤1:导入ssm的依赖

```
<!-- SpringMVC -->
<dependency>
    <groupId>org.springframework</groupId>
    <artifactId>spring-webmvc</artifactId>
    <version>5.2.2.RELEASE</version>
</dependency>
<!-- Spring JDBC依赖，必须与其它Spring依赖使用完全相同的版本 -->
<dependency>
    <groupId>org.springframework</groupId>
    <artifactId>spring-jdbc</artifactId>
    <version>5.2.2.RELEASE</version>
</dependency>
<!-- Mybatis框架 -->
<dependency>
    <groupId>org.mybatis</groupId>
    <artifactId>mybatis</artifactId>
    <version>3.5.0</version>
</dependency>
<!-- MyBatis整合Spring -->
<dependency>
    <groupId>org.mybatis</groupId>
    <artifactId>mybatis-spring</artifactId>
    <version>2.0.1</version>
</dependency>
<!-- Thymeleaf -->
<dependency>
    <groupId>org.thymeleaf</groupId>
    <artifactId>thymeleaf</artifactId>
    <version>3.0.11.RELEASE</version>
</dependency>
<!-- Thymeleaf整合Spring -->
<dependency>
    <groupId>org.thymeleaf</groupId>
    <artifactId>thymeleaf-spring5</artifactId>
    <version>3.0.11.RELEASE</version>
</dependency>
<!-- 连接MySQL数据库的依赖 -->
<dependency>
    <groupId>mysql</groupId>
    <artifactId>mysql-connector-java</artifactId>
    <version>8.0.15</version>
</dependency>
<!-- 数据库连接池 -->
<dependency>
    <groupId>com.alibaba</groupId>
    <artifactId>druid</artifactId>
    <version>1.1.21</version>
</dependency>
<!-- 单元测试 -->
<dependency>
    <groupId>junit</groupId>
    <artifactId>junit</artifactId>
    <version>4.13</version>
    <scope>test</scope>
</dependency>
<dependency>
    <groupId>javax.servlet</groupId>
    <artifactId>javax.servlet-api</artifactId>
    <version>3.1.0</version>
    <scope>provided</scope>
</dependency>
<dependency>
    <groupId>org.slf4j</groupId>
    <artifactId>slf4j-log4j12</artifactId>
    <version>1.7.25</version>
</dependency>
```

步骤2:

复制jdbc.properties文件到resources文件夹下

```
db.driver=com.mysql.cj.jdbc.Driver
db.url=jdbc:mysql://localhost:3306/vrd?characterEncoding=utf8&useSSL=false&serverTimezone=Asia/Shanghai&rewriteBatchedStatements=true
db.username=root
db.password=root
db.maxActive=10
db.initialSize=2
```

步骤3:

编写Mybatis的配置文件

```

@PropertySource("classpath:jdbc.properties")
public class MyBatisConfig {

    @Bean
    public DataSource dataSource(
            @Value("${db.driver}") String driver,
            @Value("${db.url}") String url,
            @Value("${db.username}") String username,
            @Value("${db.password}") String password,
            @Value("${db.maxActive}") int maxActive,
            @Value("${db.initialSize}") int initialSize) {
        DruidDataSource ds = new DruidDataSource();
        ds.setDriverClassName(driver);
        ds.setUrl(url);
        ds.setUsername(username);
        ds.setPassword(password);
        ds.setMaxActive(maxActive);
        ds.setInitialSize(initialSize);
        return ds;
    }
}
```

配置完成测试配置可用

在test中创建测试类

```
 @Test
    public void testDataSource() throws SQLException {
        DataSource ds=ctx.getBean(
                "dataSource",DataSource.class);
        String sql="select username from vrduser where id=1";
        try (Connection conn=ds.getConnection()){
            Statement st=conn.createStatement();
            ResultSet rs=st.executeQuery(sql);
            while(rs.next()){
                System.out.println(rs.getString(1));
            }
        }catch (Exception e){
            e.printStackTrace();
        }

    }
```

## MyBatis基本使用

我们下面完成一个HelloWorld程序

步骤1:

新建一个cn.tedu.mapper包

包中新建一个接口DemoMapper

```
public interface DemoMapper {

    //下面的方法就是Mybatis实现的查询方法了
    //不需要编写实现类
    @Select("select username from vrduser where id=1")
    public String hello();

}
```

上面的接口会由我们注入的SqlSessionFactory来自动生成实现类

注入这个类

MyBatisConfig中代码如下

```
@PropertySource("classpath:jdbc.properties")
@MapperScan("cn.tedu.mapper")
public class MyBatisConfig {

    @Bean
    public DataSource dataSource(
      //代码略
    }

    //SqlSessionFactory这个类时Mybatis中的一个重要的类
    //它的功能非常强大,能根据接口中声明的信息
    //自动实现这个接口的实现类,并将这个实现类注入到Spring容器以便我们使用
    @Bean
    public SqlSessionFactory sqlSessionFactory(
            DataSource dataSource) throws Exception {
        SqlSessionFactoryBean bean=
                new SqlSessionFactoryBean();
        bean.setDataSource(dataSource);
        return bean.getObject();
    }
}
```

需要注意类上新加了注解@MapperScan("cn.tedu.mapper")

表示指定功能强大的SqlSessionFactory类要扫描并生成实现类的包

配置完毕

执行测试

```
 @Test
    public void testFactory(){
        SqlSessionFactory factory=ctx.getBean(
                "sqlSessionFactory",SqlSessionFactory.class);
        System.out.println(factory);
    }
    //执行Mapper接口中的方法
    @Test
    public void testUsername(){
        DemoMapper mapper=ctx.getBean(
                "demoMapper",DemoMapper.class);
        String name=mapper.hello();
        System.out.println(name);
    }
```

# 使用Mybatis实现简单CRUD操作

## 准备数据

我们新建一个数据库,添加一些数据以备Mybatis使用

```
create database tedu_ums;
use tedu_ums
```

创建表

```
CREATE TABLE t_user (
  id INT(11) AUTO_INCREMENT COMMENT '用户id',
  username VARCHAR(20) UNIQUE NOT NULL COMMENT '用户名',
  password VARCHAR(20) NOT NULL COMMENT '密码',
  age INT COMMENT '年龄',
  phone VARCHAR(20) COMMENT '手机号码',
  email VARCHAR(20) COMMENT '电子邮箱',
  PRIMARY KEY (id)
) DEFAULT CHARSET=utf8;
```

添加数据

```
INSERT INTO t_user (username, password, phone, age, email) VALUES 
  ('Frank01', '1234', '13800138001', 28, 'frank01@163.com'),
  ('Frank04', '1234', '13800138004', 33, 'frank04@163.com'),
  ('Frank05', '1234', '13800138005', 21, 'frank05@163.com'),
  ('Frank09', '1234', '13800138009', 26, 'frank09@163.com'),
  ('Frank06', '1234', '13800138006', 29, 'frank06@163.com'),
  ('Frank11', '1234', '13800138011', 24, 'frank11@163.com'),
  ('Frank12', '1234', '13800138012', 23, 'frank12@163.com'),
  ('Frank07', '1234', '13800138007', 31, 'frank07@163.com'),
  ('Frank08', '1234', '13800138008', 22, 'frank08@163.com'),
  ('Frank02', '1234', '13800138002', 27, 'frank02@163.com'),
  ('Frank03', '1234', '13800138003', 32, 'frank03@163.com'),
  ('Frank10', '1234', '13800138010', 30, 'frank10@163.com'),
  ('Frank13', '1234', '13800138013', 25, 'frank13@163.com');
```

需要注意我们更换的数据库

需要在jdbc.properties配置文件中修改

```
db.url=jdbc:mysql://localhost:3306/tedu_ums?characterEncoding=utf8&useSSL=false&serverTimezone=Asia/Shanghai&rewriteBatchedStatements=true
```

将数据库名修改为tedu_ums

## 查询功能

下面无论做什么操作,都需要对应t_user表的实体类

否则不方便,所以我们先创建它

新建一个包,标准的实体类包名称有很多,都是业界常见的

entity\bean\model\pojo\domain等

我们创建cn.tedu.entity

```
public class User implements Serializable {

    //注意:所有属性名必须和数据库的列名完全一致
    private Integer id;
    private String username;
    private String password;
    private Integer age;
    private String phone;
    private String email;

    public User(){
    }

    public User(Integer id, String username, String password, Integer age, String phone, String email) {
        this.id = id;
        this.username = username;
        this.password = password;
        this.age = age;
        this.phone = phone;
        this.email = email;
    }
    ..省略其它代码
}
```

执行按id查询出User对象的查询方法

mapper包中新建一个接口UserMapper

其中编写方法,代码如下:

```
public interface UserMapper {

    @Select("select id,username,password,age,phone,email" +
            "from t_user where id=#{id}")
    User findUserById(Integer id);
}
```

测试:

```
@Test
    public void selectId(){
        UserMapper mapper=ctx.getBean(
                "userMapper", UserMapper.class);
        User user=mapper.findUserById(1);
        System.out.println(user);

    }
```

运行输出一个用户的id即可

Mybatis从数据库中查询出指定id的数据后

会根据列名和java实体类的属性对应的关系一一赋值

依赖的是实体类的set方法

上面是查询一行

下面我们来查询多行

UserMapper接口添加如下方法

```
 @Select("select id,username,password,age,phone,email" +
            " from t_user")
    List<User> findAllUsers();
```

测试代码

```
@Test
    public void selectAll(){
        UserMapper mapper=ctx.getBean(
                "userMapper",UserMapper.class);
        List<User> list=mapper.findAllUsers();
        for (User u:list) {
            System.out.println(u);
        }
    }
```

## 新增功能

在UserMapper中添加如下方法

```
//新增用户的方法
    //返回的Integer是受影响的行数 新增1行时 1行受影响表示成功
    @Insert("insert into t_user values" +
            "(null,#{username},#{password},#{age},#{phone},#{email})")
    Integer insertUser(User user);
```

sql语句中出现的#{xxx}实际上是去调用user对象的getXxx方法

所以#{}中的内容必须和user属性对应

测试

```
@Test
    public void insert(){
        User user=new User(null,"Tom","123",
                28,"13811012345","tom@tedu.cn");
        UserMapper mapper=ctx.getBean(
                "userMapper",UserMapper.class);
        Integer num=mapper.insertUser(user);
        System.out.println(num);

    }
```

今后做项目时可能需要这样的需求

新增一个对象到数据库后,我们想立即获得这个对象的id怎么实现

下面我们就来学习

如果新增User后立即获得这个User的id

UserMapper新增方法

```
 //下面的方法是新增用户并将新增后自增的id赋值给用户对象的属性
    @Insert("insert into t_user values" +
            "(null,#{username},#{password},#{age},#{phone},#{email})")
    //useGeneratedKeys表示获取生成的主键 true就是要获取
    //keyProperty表示获得的主键要赋给user的哪个属性
    @Options(useGeneratedKeys = true, keyProperty = "id")
    Integer insertUserWithId(User user);
```

测试代码

```
 @Test
    public void insertWithId(){
        User user=new User(null,"Jerry","456",
                21,"13811013789","jerry@tedu.cn");
        UserMapper mapper=ctx.getBean(
                "userMapper",UserMapper.class);
        Integer num=mapper.insertUserWithId(user);
        System.out.println(num);
        System.out.println(user);

    }
```

## 修改功能

我们先实现一个全行修改

根据user对象的id将id匹配的行除了id列之外的所有列都修改为当前user对象的值

在UserMapper中新建方法

```
@Update("update t_user set username=#{username}," +
            "password=#{password},age=#{age},phone=#{phone}," +
            "email=#{email} where id=#{id}")
    Integer updateUser(User user);
```

测试

```
 @Test
    public void updateUser(){
        User user=new User(16,"LiLei","888",25,
                "13812345678","lilei@qq.com");
        UserMapper mapper=ctx.getBean(
                "userMapper",UserMapper.class);
        Integer num=mapper.updateUser(user);
        System.out.println(num);
    }
```

下面我们实现一个按照给定的id修改email的方法

在Mapper中编写代码如下

```
//按id修改email的方法
    @Update("update t_user set email=#{email} where id=#{id}")
    Integer updateEmailById(Integer id,String email);
```

Mybatis框架接口中编写的方法如果有两个或以上的参数会出现问题
因为默认情况下.java文件编译成.class文件后
所有局部变量的名称都会丢失所以在运行时Mybatis不能根据给定的参数名称
去对应sql语句中#{}中的内容

所以上面编写的方法在测试时会报错

解决这个问题有3个方案

1.将#{}里面的内容修改为arg0\arg1

```
 @Update("update t_user set email=#{arg1} where id=#{arg0}")
    Integer updateEmailById(Integer id,String email);
```

其中#{arg0}表示参数列表中的第一个参数

#{arg1}表示第二个参数

2.将#{}里面的内容修改为param1\param2

```
 @Update("update t_user set email=#{param2} where id=#{param1}")
    Integer updateEmailById(Integer id,String email);
```

其中#{param1}表示参数列表中的第一个参数

#{param2}表示第二个参数

3.使用Mybatis提供的注解标记每个参数对应的名称

```
  @Update("update t_user set email=#{email} where id=#{id}")
    Integer updateEmailById(
            @Param("id") Integer id,
            @Param("email") String email);
```

其中@Param("id")表示这个注解后面的参数对应#{id}

其中@Param("email")表示这个注解后面的参数对应#{email}

测试代码

```
 @Test
    public void updateEmail(){
        Integer id=14;
        String email="tom@sina.com";
        UserMapper userMapper=ctx.getBean(
                "userMapper",UserMapper.class);
        Integer num=userMapper.updateEmailById(id,email);
        System.out.println(num);
    }
```

## 删除功能

删除功能是这几个功能中最简单的

UserMapper中编写方法代码如下

```
//按id删除用户
    @Delete("delete from t_user where id=#{id}")
    public Integer deleteById(Integer id);
```

测试代码

```
@Test
    public void deleteById(){
        UserMapper mapper=ctx.getBean(
                "userMapper",UserMapper.class);
        Integer num=mapper.deleteById(14);
        System.out.println(num);
    }
```









