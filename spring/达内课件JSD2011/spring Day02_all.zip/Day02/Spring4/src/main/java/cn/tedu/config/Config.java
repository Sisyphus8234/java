package cn.tedu.config;

import com.alibaba.druid.pool.DruidDataSource;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;
import org.springframework.context.annotation.PropertySource;

import java.util.ArrayList;
import java.util.List;

@Configuration
@ComponentScan("cn.tedu")
@PropertySource("classpath:jdbc.properties")
public class Config {

    @Bean
    public DruidDataSource dataSource(
            @Value("${db.url}") String url,
            @Value("${db.username}") String username,
            @Value("${db.password}") String password,
            @Value("${db.maxActive}") Integer maxActive,
            @Value("${db.initialSize}") Integer initialSize){
        DruidDataSource dataSource = new DruidDataSource();
        dataSource.setUrl(url);
        dataSource.setUsername(username);
        dataSource.setPassword(password);
        dataSource.setMaxActive(maxActive);
        dataSource.setInitialSize(initialSize);
        return dataSource;
    }

    @Bean
    public List<String> demo(
           @Value("${db.url}") String url,
           @Value("${db.username}") String username,
           @Value("${db.password}") String password
    ){
        //测试读取Properties文件
        System.out.println(url);
        System.out.println(username);
        System.out.println(password);
        return new ArrayList<>();
    }

}








