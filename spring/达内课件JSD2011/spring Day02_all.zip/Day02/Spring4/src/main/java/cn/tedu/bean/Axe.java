package cn.tedu.bean;

import org.springframework.stereotype.Component;

import java.io.Serializable;
@Component
public class Axe implements Serializable, Tool {
    private String name = "开天斧";
    public String getName() {
        return name;
    }
    public void setName(String name) {
        this.name = name;
    }
    @Override
    public String toString() {
        return name;
    }
}
