package cn.tedu.bean;

import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.io.Serializable;

@Component
public class Worker implements Serializable {
    private String name = "光头强";
    @Resource
    private Tool tool;
    public void work(){
        System.out.println(name+"使用"+tool+"砍树!");
    }

    public void setTool(Tool tool) {
        this.tool = tool;
    }

    public Tool getTool() {
        return tool;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
