package cn.tedu.bean;

/**
 * 工具类型接口
 */
public interface Tool {
}
