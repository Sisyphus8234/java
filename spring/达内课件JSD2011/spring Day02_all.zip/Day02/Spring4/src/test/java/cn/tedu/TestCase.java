package cn.tedu;

import cn.tedu.bean.Worker;
import cn.tedu.config.Config;
import com.alibaba.druid.pool.DruidDataSource;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class TestCase {
    AnnotationConfigApplicationContext ctx;
    @Before
    public void init(){
        ctx = new AnnotationConfigApplicationContext(
                Config.class);
    }
    @After
    public void destroy(){
        ctx.close();
    }
    @Test
    public void testWorker(){
        Worker worker=ctx.getBean(Worker.class);
        worker.work();
    }

    @Test
    public void testNewWorker(){
        //这个是一个: 错误案例!!!
        //如果脱离Spring环境, 自己控制创建对象,
        //不可能进行 DI
        Worker worker = new Worker();
        worker.work();
    }

    @Test
    public void testDataSource(){
        DruidDataSource dataSource =
                ctx.getBean(DruidDataSource.class);
        String sql = "SELECT 'Hello World!'";
        try(Connection conn = dataSource.getConnection()){
            Statement st = conn.createStatement();
            ResultSet rs=st.executeQuery(sql);
            while (rs.next()){
                System.out.println(rs.getString(1));
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
