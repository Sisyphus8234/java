package cn.tedu.bean;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;
import java.io.Serializable;

@Component
public class Worker implements Serializable {
    private String name = "光头强";
    //Spring 提供的自动注入功能: 先根据类型匹配,再根据名字匹配
    //@Autowired
    //@Resource
    private Saw saw;
    public Worker(){
    }
    // @Autowired 标注在构造器上, Spring会自动调用构造器注入属性值
    // @Autowired
    public Worker(Saw saw){
        System.out.println("Worker(Saw saw)");
        this.saw = saw;
    }
    public void work(){
        System.out.println(name+"使用"+saw+"砍树!");
    }

    public Saw getSaw() {
        return saw;
    }
    //@Autowired 标注在方法上, Spring就会
    //自动的调用方法, 注入属性值
    //@Autowired
    @Resource
    public void setSaw(Saw saw) {
        System.out.println("setSaw()");
        this.saw = saw;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


}
