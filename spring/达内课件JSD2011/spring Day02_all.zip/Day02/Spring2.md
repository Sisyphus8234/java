# Spring

## IoC 控制反转

将对象的管理控制器权交给当前容器环境管理, 程序在使用对象时候, 从容器中获取对象即可. 这样可以简化程序管理复杂对象.

Java Bean容器:  由于Spring可以管理大量的JavaBean对象, 可以看做是盛放了大量的Java Bean对象的"容器", 所以Spring 为 Java Bean容器, 简称 Bean容器, 也称为 IoC 容器. 

容器:  XXX的容器, 是完全不同事物. Spring是JavaBean容器, Tomcat是Servlet容器, 集合类是对象容器 , 这些容器完全不同!!!!

集合类是对象容器, 有些面试官称为 "容器类" 或 "容器".

## DI 依赖注入

Spring 容器提供的核心功能: 将程序运行期间业务过程使用(依赖)的对象注入(赋值)到合适位置, 称为依赖注入(DI).

- 依赖: 一个业务过程需要的前提条件. 
  - 西红柿炒蛋依赖西红柿和鸡蛋
  - 光头强砍树依赖电锯
  - ... ... 

- 注入: 将一个业务过程依赖的事物放到合适位置.

## 配置类注入

注入原理

![image-20210308111832441](image-20210308111832441.png)

案例:

1. Saw

   ```java
   package cn.tedu.bean;
   
   import java.io.Serializable;
   
   public class Saw implements Serializable {
       private String name = "寒冰锯";
       public void setName(String name) {
           this.name = name;
       }
       public String getName() {
           return name;
       }
       @Override
       public String toString() {
           return name;
       }
   }
   ```

2. Worker

   ```java
   package cn.tedu.bean;
   
   import java.io.Serializable;
   
   public class Worker implements Serializable {
       private String name = "光头强";
       private Saw saw;
       public void work(){
           System.out.println(name+"使用"+saw+"砍树!");
       }
       public void setSaw(Saw saw) {
           this.saw = saw;
       }
       public Saw getSaw() {
           return saw;
       }
   }
   ```

3. 配置:

   ```java
   @Configuration
   public class Config {
       @Bean
       public Saw saw(){
           return new Saw();
       }
       /**
        * Spring容器会根据配置方法参数, 
        * 在Spring容器中寻找匹配类型相同的
        * Java Bean 对象, 如果匹配到相同类型就自动将
        * Java Bean对象注入到
        * 方法的参数中, 这个现象称为 "DI" 依赖注入
        * @param s
        * @return
        */
       @Bean
       public Worker worker(Saw s){
           Worker worker = new Worker();
           worker.setSaw(s);
           return worker;
       }
   }
   ```

4. 测试

   ```java
   public class TestCase {
       AnnotationConfigApplicationContext ctx;
       @Before
       public void init(){
           ctx = new AnnotationConfigApplicationContext(
               Config.class);
       }
   
       @After
       public void destroy(){
           ctx.close();
       }
   
       @Test
       public void testWorker(){
           /*
            * 测试依赖注入功能, 如果工人的saw属性不为空, 
            * 则说明Spring成功
            * 的将 "寒冰锯" 注入给工人
            */
           Worker worker = ctx.getBean(Worker.class);
           worker.work();
       }
   }
   ```

### Spring 自动注入匹配规则

Spring 自动注入的匹配规则:

- 根据类型匹配: 根据注入对象的类型在Spring中匹配寻找类型兼容的JavaBean对象
  - 如果没有找到, 则抛出异常! 
  - 如果找到类型唯一匹配的JavaBean对象, 就注入成功
  - 如果找到多个java bean则按照名字进一步匹配
- 根据名字匹配, 根据当前注入的变量名, 匹配JavaBean的ID
  - 匹配成功, 则注入成功
  - 匹配失败, 则抛出异常

> 简单理解: 先按照类型匹配(By Type), 再按照名字匹配(By Name)
>
> 使用建议: 尽量使用默认规则进行匹配注入

案例:

```java
@Configuration
public class Config {
    @Bean
    public Saw saw(){
        return new Saw();
    }
    @Bean("s")
    public Saw s(){
        return new Saw();
    }

    /**
     * Spring容器会根据配置方法参数, 
     * 在Spring容器中寻找匹配类型相同的
     * Java Bean 对象, 如果匹配到相同类型
     * 就自动将Java Bean对象注入到
     * 方法的参数中, 这个现象称为 "DI" 依赖注入
     * @param s
     * @return
     */
    @Bean
    public Worker worker(Saw s){
        Worker worker = new Worker();
        worker.setSaw(s);
        return worker;
    }
}
```

## 注解注入

Spring 提供了@Autowired 注解, 用于再组件扫描时候实现注入功能.

使用更加简单.

原理: 

![image-20210308115916268](image-20210308115916268.png)

案例:

1. Saw

   ```java
   package cn.tedu.bean;
   
   import org.springframework.stereotype.Component;
   
   import java.io.Serializable;
   
   @Component
   public class Saw implements Serializable {
       private String name= "寒冰锯";
       public String getName() {
           return name;
       }
       public void setName(String name) {
           this.name = name;
       }
       @Override
       public String toString() {
           return name;
       }
   }
   ```

2. Worker

   ```java
   package cn.tedu.bean;
   
   import org.springframework.beans.factory.annotation.Autowired;
   import org.springframework.stereotype.Component;
   
   import java.io.Serializable;
   
   @Component
   public class Worker implements Serializable {
       private String name = "光头强";
       //Spring 提供的自动注入功能: 先根据类型匹配,再根据名字匹配
       @Autowired
       private Saw saw;
       public void work(){
           System.out.println(name+"使用"+saw+"砍树!");
       }
   
       public String getName() {
           return name;
       }
   
       public void setName(String name) {
           this.name = name;
       }
   
       public Saw getSaw() {
           return saw;
       }
   
       public void setSaw(Saw saw) {
           this.saw = saw;
       }
   }
   ```

3. 配置

   ```java
   @Configuration
   //扫描当前包和其子包
   @ComponentScan("cn.tedu")
   public class Config {
   }
   ```

4. 测试:

   ```java
   public class TestCase {
       AnnotationConfigApplicationContext ctx;
       @Before
       public void init(){
           ctx=new AnnotationConfigApplicationContext(
                   Config.class);
       }
       @After
       public void destroy(){
           ctx.close();
       }
       @Test
       public void testWorker(){
           Worker worker = ctx.getBean(Worker.class);
           worker.work();
       }
   }
   ```

@Autowired 注解的功能:

- 标注在属性上, 可以进行对象属性注入
  - Spring 3, 4 常用, Spring 5开始不推荐了! 由于使用方便, 但是仍然很多人在使用!
- 标注在set方法上, 进行set方法注入, 就是调用Set方法注入属性值
- 标注在构造器上, 进行构造参数注入(就是调用有参数构造器)

@Resource 注解

- 是Java官方定义的注入注解, Spring支持了@Resource. 在Spring中可以使用@Resource注解注入属性
- 可以标注在 属性 和 set方法上, 其功能和 @Autowired 大致一样. 

@Autowired  和 @Resource 的区别? 

匹配规则不同: 

- @Autowired **先按类型匹配, 再按照名称匹配** 
  - 参考前述: Spring 自动注入的匹配规则
- @Resource **先按照名字匹配, 再按照类型匹配**
  - 根据变量名查找名称一致的BeanID
    - 找到名字相同的BeanID, 检查Bean的类型和变量类型是否兼容, 如兼容就注入. 
    - 没有找到名字相同的Bean对象, 就按照类型查找唯一的Bean对象, 如果没有找到唯一对象就抛异常

- **如果不严格区别, 其结果基本一样!**

案例: 

```java
@Component
public class Worker implements Serializable {
    private String name = "光头强";
    //Spring 提供的自动注入功能: 先根据类型匹配,再根据名字匹配
    //@Autowired
    //@Resource
    private Saw saw;
    public Worker(){
    }
    // @Autowired 标注在构造器上, Spring会自动调用构造器注入属性值
    // @Autowired
    public Worker(Saw saw){
        System.out.println("Worker(Saw saw)");
        this.saw = saw;
    }
    public void work(){
        System.out.println(name+"使用"+saw+"砍树!");
    }

    public Saw getSaw() {
        return saw;
    }
    //@Autowired 标注在方法上, Spring就会
    //自动的调用方法, 注入属性值
    //@Autowired
    @Resource
    public void setSaw(Saw saw) {
        System.out.println("setSaw()");
        this.saw = saw;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

}
```



### 利用IoC/DI解耦

耦合性: 组件和组件关联的紧密程度称为耦合性.  

- 紧密连接称为紧耦合
- 松散连接称为松耦合

利用接口和IoC/DI可以实现软件组件的解耦

![image-20210308160220593](image-20210308160220593.png)

案例: 

1. Tool 接口

   ```java
   /**
    * 工具类型接口
    */
   public interface Tool {
   }
   ```

2. Axe

   ```java
   @Component
   public class Axe implements Serializable, Tool {
       private String name = "开天斧";
       public String getName() {
           return name;
       }
       public void setName(String name) {
           this.name = name;
       }
       @Override
       public String toString() {
           return name;
       }
   }
   ```

3. Saw

   ```java
   public class Saw implements Serializable, Tool {
       private String name = "寒冰锯";
       public String getName() {
           return name;
       }
       public void setName(String name) {
           this.name = name;
       }
       @Override
       public String toString() {
           return name;
       }
   }
   ```

4. Worker

   ```java
   @Component
   public class Worker implements Serializable {
       private String name = "光头强";
       @Resource
       private Tool tool;
       public void work(){
           System.out.println(name+"使用"+tool+"砍树!");
       }
   
       public void setTool(Tool tool) {
           this.tool = tool;
       }
   
       public Tool getTool() {
           return tool;
       }
   
       public void setName(String name) {
           this.name = name;
       }
   
       public String getName() {
           return name;
       }
   }
   ```

5. Config

   ```java
   @Configuration
   @ComponentScan(&quot;cn.tedu&quot;)
   public class Config {
   }
   ```

6. 测试

   ```java
   public class TestCase {
       AnnotationConfigApplicationContext ctx;
       @Before
       public void init(){
           ctx = new AnnotationConfigApplicationContext(
                   Config.class);
       }
       @After
       public void destroy(){
           ctx.close();
       }
       @Test
       public void testWorker(){
           Worker worker=ctx.getBean(Worker.class);
           worker.work();
       }
   }
   ```

### Spring 配置文件读取功能

软件开发中将软件的参数保存在properties文件中, Spring提供了注解和表达式, 可以简化配置文件的读取. 使用这些数据和表达式, 可以简化开发.

![image-20210308175639532](image-20210308175639532.png)

案例:

1. 导入JDBC驱动和数据库连接池

   ```xml
   <dependency>
       <groupId>com.alibaba</groupId>
       <artifactId>druid</artifactId>
       <version>1.1.23</version>
   </dependency>
   <dependency>
       <groupId>mysql</groupId>
       <artifactId>mysql-connector-java</artifactId>
       <version>8.0.21</version>
   </dependency>
   ```

2. 在resources文件夹中添加 jdbc.properties 文件

   ```properties
   db.driver=com.mysql.jdbc.Driver
   db.url=jdbc:mysql://localhost:3306/mysql?characterEncoding=utf8&useSSL=false&serverTimezone=Asia/Shanghai&rewriteBatchedStatements=true
   db.username=root
   db.password=root
   db.maxActive=10
   db.initialSize=2
   ```

3. 在Config中读取配置文件

   ```java
   @Configuration
   @ComponentScan("cn.tedu")
   @PropertySource("classpath:jdbc.properties")
   public class Config {
   
       @Bean
       public DruidDataSource dataSource(
           @Value("${db.url}") String url,
           @Value("${db.username}") String username,
           @Value("${db.password}") String password,
           @Value("${db.maxActive}") Integer maxActive,
           @Value("${db.initialSize}") Integer initialSize){
           DruidDataSource dataSource = 
               new DruidDataSource();
           dataSource.setUrl(url);
           dataSource.setUsername(username);
           dataSource.setPassword(password);
           dataSource.setMaxActive(maxActive);
           dataSource.setInitialSize(initialSize);
           return dataSource;
       }
   }
   ```

4. 测试:

   ```java
   @Test
   public void testDataSource(){
       DruidDataSource dataSource =
               ctx.getBean(DruidDataSource.class);
       String sql = "SELECT 'Hello World!'";
       try(Connection conn = dataSource.getConnection()){
           Statement st = conn.createStatement();
           ResultSet rs=st.executeQuery(sql);
           while (rs.next()){
               System.out.println(rs.getString(1));
           }
       }catch (Exception e){
           e.printStackTrace();
       }
   }
   ```



## 作业

1. 创建新项目，完全重写课堂案例代码
2. 解藕案例1：
   1. 用@Component注解实现，人使用书写工具写字，书写工具有两种 铅笔和毛笔
   2. 用@Bean注解实现，人使用书写工具写字，书写工具有两种 铅笔和毛笔
3. 解藕案例2：
   1. 用@Component注解实现，驾驶员驾驶交通工具，交通工具有两种 小汽车和卡车
   2. 用@Bean注解实现，驾驶员驾驶交通工具，交通工具有两种 小汽车和卡车







