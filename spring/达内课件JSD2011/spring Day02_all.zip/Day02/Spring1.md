# Spring

## Spring Framework

Spring 框架: Spring提供的软件半成品, Spring提供了软件中常见组件, 利用Spring框架可以快速开发软件.

Spring两大核心功能: 

1. IoC/DI 控制反转/依赖注入
2. AOP 面向切面(儿)编程

### 控制反转IoC

控制反转就是指将"对象"的创建管理权限交给系统环境(Spring), 应用软件需要使用对象时候从环境(Spring)中获得对象, 然后使用对象. 这种被动使用对象的方式称为 控制反转 IoC. 

在软件使用复杂对象时候, 由于不用关心对象组件的创建过程, 只关注使用, 这样就可以大大简化软件的开发. 

### 控制反转 HelloWorld

利用一个简单对象展示一下Spring提供的对象管理功能.  用于证明Spring提供了对象管理功能(IoC功能). 

步骤:

1. 声明一个类, 用于证明Spring可以管理对象

   ```java
   public class DemoBean {
       @Override
       public String toString() {
           return "Hello World!";
       }
   }
   ```

2. 创建项目, 利用Maven导入Spring框架核心组件.

   ```xml
   <properties>
       <!-- 设置 JDK 版本为 1.8 -->
       <maven.compiler.target>1.8</maven.compiler.target>
       <maven.compiler.source>1.8</maven.compiler.source>
       <!-- 设置编码为 UTF-8 -->
       <project.build.sourceEncoding>
           UTF-8</project.build.sourceEncoding>
       <project.reporting.outputEncoding>
           UTF-8</project.reporting.outputEncoding>
       <maven.compiler.encoding>
           UTF-8</maven.compiler.encoding>
   </properties>
   <dependencies>
       <!-- Spring Context -->
       <dependency>
           <groupId>org.springframework</groupId>
           <artifactId>spring-context</artifactId>
           <version>5.2.2.RELEASE</version>
       </dependency>
       <dependency>
           <groupId>javax.annotation</groupId>
           <artifactId>javax.annotation-api</artifactId>
           <version>1.3.2</version>
       </dependency>
   </dependencies>
   ```

3. 编写一个配置类, 告诉Spring, 启动以后创建哪个对象.

   ```java
   package cn.tedu.config;
   import cn.tedu.spring1.DemoBean;
   import org.springframework.context.annotation.Bean;
   import org.springframework.context.annotation.Configuration;
   /**
    * @Configuration Spring提供的注解, 用于标注在Spring配置类上
    * 表示当前类作为Spring的配置文件, 其中可以声明Spring中创建的对象
    */
   @Configuration
   public class Config {
       /**
        * @Bean Spring提供的注解, 标注在创建对象的方法上
        * Spring启动时候, 会自动寻找 配置类中标注了@Bean注解的方法
        * 找到以后会执行方法创建对象.
        * 方法必须创建一个新对象, 公用方法, 方法名随意
        * @return
        */
       @Bean
       public DemoBean demoBean(){
           return new DemoBean();
       }
   }
   ```

4. 启动Spring, 从Spring获得创建好的对象, 如果能够证明对象已经被创建了, 就证明了Spring可以管理对象.

   ```java
   public class Test {
       public static void main(String[] args) {
           /**
            * 测试Spring可以创建管理对象(IoC)
            * Annotation : 注解
            * Config : 配置
            * Application: 应用程序
            * Context: 上下文
            * 注解配置应用程序上下文 == Spring
            * 创建 AnnotationConfigApplicationContext对象时候,
            * 必须提供配置类的类名 Config.class!
            */
           AnnotationConfigApplicationContext ctx =
                   new AnnotationConfigApplicationContext(
               	Config.class);
           //Spring 提供了一个getBean方法, 参数是类型, 
           //返回值是Spring 创建的对象, 如果前述配置的DemoBean
           DemoBean bean = ctx.getBean(DemoBean.class);
           //检查对象. 输出bean, 输出时候自动调用 toString()
           System.out.println(bean);
           //如有HelloWorld就证明 Spring 管理创建了DemoBean对象
       }
   ```

> Maven 组件搜索网站 https://mvnrepository.com/

#### Bean ID

Spring 在IoC容器中为对象分配为唯一的ID, 当出现相同类型对象冲突时候, 就可以使用Bean ID找到对象. 

案例:

1. 在配置文件中创建两个类型一样的对象:

   ```java
   @Configuration
   public class Config {
       /**
        * @Bean Spring提供的注解, 标注在创建对象的方法上
        * Spring启动时候, 会自动寻找 配置类中标注了@Bean注解的方法
        * 找到以后会执行方法创建对象.
        * 方法必须创建一个新对象, 公用方法, 方法名随意
        * @return
        */
       @Bean
       public DemoBean demoBean(){
           return new DemoBean();
       }
       //创建对象的方法名, 就是为对象分配的唯一 BeanID
       @Bean
       public DemoBean demoBean1(){
           return new DemoBean();
       }
   }
   ```

2. 测试

   ```Java
   public class Test {
       public static void main(String[] args) {
           /**
            * 测试Spring可以创建管理对象(IoC)
            * Annotation : 注解
            * Config : 配置
            * Application: 应用程序
            * Context: 上下文
            * 注解配置应用程序上下文 == Spring
            * 创建 AnnotationConfigApplicationContext对象时候,
            * 必须提供配置类的类名 Config.class!
            */
           AnnotationConfigApplicationContext ctx =
                   new AnnotationConfigApplicationContext(
               	Config.class);
           //当按照类型获取对象有冲突时候, 就可以按照对象的ID获取对象
           //默认情况下, 对象ID就是配置文件中创建对象的方法名
           //getBean方法根据对象的ID获取对象, 参数是对象的ID,
           //如果对象ID错误, 抛出异常!
           DemoBean demoBean = 
               ctx.getBean("demoBean1", DemoBean.class);
           System.out.println(demoBean);
       }
   }
   ```

### JUnit 

是常用的Java测试框架, 工作中经常使用JUnit进程软件单元测试. 可以用于测试Spring提供的功能.

使用步骤:

1. 导入JUnit包

   ```xml
   <dependency>
       <groupId>junit</groupId>
       <artifactId>junit</artifactId>
       <version>4.13</version>
   </dependency>
   ```

2. 编写测试案例, 测试方法上使用@Test注解

   ```java
   /**
    * test: 测试
    * case: 案例 案子
    * 测试案例类必须是 公有类!!!
    */
   public class TestCase {
       /**
        * 被测试方法前面要标注 @Test
        * 测试方法必须是 公有 无返回值 无参数 的方法
        */
       @Test
       public void hello(){
           System.out.println("Hello World!");
       }
   
       @Test
       public void demo(){
           System.out.println("Demo");
       }
   }
   ```

3. 执行测试方法

#### 利用JUnit测试Spring

编写测试案例, 利用@Before初始化Spring, 利用@After销毁Spring

```java
/**
 * test: 测试
 * case: 案例 案子
 * 测试案例类必须是 公有类!!!
 */
public class TestCase {
    AnnotationConfigApplicationContext ctx ;
    /**
     * JUnit提供的@Before注解标注的方法, 在测试案例之前执行
     * 一般用于初始化测试之前使用的资源
     */
    @Before
    public void init(){
        System.out.println("在测试案例之前执行");
        ctx=new AnnotationConfigApplicationContext(
            Config.class);
    }

    /**
     * After 在XXX之后, 
     * JUnit中@After注解的作用是在测试案例之后执行
     * 用于回收测试之前创建的资源
     * destroy: 销毁
     */
    @After
    public void destroy(){
        //Spring提供了关闭Spring的方法,释放Spring中的对象
        ctx.close();
        System.out.println("释放资源");
    }
    /**
     * 测试一下, 如果Spring中相同类型的对象有一个以上时,
     * 按照类型获取对象将出现异常
     */
    @Test
    public void testGetBean(){
        DemoBean demoBean = ctx.getBean(DemoBean.class);
        System.out.println(demoBean);
    }
    @Test
    public void testBeanID(){
        DemoBean demoBean = 
            ctx.getBean("demoBeanX",DemoBean.class);
        System.out.println(demoBean);
    }
}
```

### Java Bean 

符合一定规范的Java类型称为JavaBean, 按照规范约定的Java类型就像咖啡豆, 每个都不同, 大体都相似.

Bean: 豆子 豆荚

java bean: 咖啡豆

JavaBean规范(普遍规范):

1. 类需要声明包
2. 有无参数构造器, 可以是默认构造器
3. 必须实现序列化接口
4. 使用get set方法访问属性

例子:

```java
package cn.tedu.spring1;
import java.io.Serializable;

public class User implements Serializable{
    private Stirng name;
	public User(){
    }
    public String getName(){
        return name;
    }
    public void setName(String name){
        this.name = name;
    }
}
```

Spring 建议, 在Spring中使用符合JavaBean规范的Java类. 如果不严格遵守JavaBean规范的Java类, Spring也可以支持!

如:

1. getBean 方法就是从Spring中查找一个JavaBean对象
2. @Bean 就是在配置文件中声明一个JavaBean对象
3. getBeanNamesForType 是按照类型找到JavaBean的名字(BeanID)

#### 关于序列化接口

- 将对象转换为字节序列, 存储到流中, 称为对象的序列化.
- 将对象字节流反向组合为对象, 称为对象反序列化
- java 提供了 对象序列化和返回序列化的API 
  - ObjectOutputStream  wtriteObject(obj)
  - ObjectInputStream  Object readObject()
  - Java 对象序列化API要求被序列化的对象类型实现 序列化接口!!!
- 序列化接口是"标识"接口
  - Java编译器编译 实现这个接口的类时候, 编译器会在类中自动添加3个方法! 这3个方法就是实现对象序列化功能的方法.
  - 对象序列化流在读写对象时候, 会自动调用这3个方法!
  - 如果不实现序列化接口 将没有这3个方法, 无法对象序列化和反序列化

### Spring单例对象

单例: 在一个软件系统中, 对象实例始终唯一的现象称为单例.

单例模式: 利用语法, 将对象约束为始终唯一一个实例, 称为单例模式.

Spring 默认情况下,  JavaBean对象是单例的.  也就是在Spring里面, 一个JavaBean对象始终是唯一的一个实例! 无论多少次使用getBean获取的对象都是唯一的一个实例. 

测试:

```java
/**
 * test: 测试
 * case: 案例 案子
 * 测试案例类必须是 公有类!!!
 */
public class TestCase {
    AnnotationConfigApplicationContext ctx ;
    /**
     * 在xxx之前, JUnit提供的@Before注解标注的方法, 
     * 在测试案例之前执行
     * 一般用于初始化测试之前使用的资源
     */
    @Before
    public void init(){
        System.out.println("在测试案例之前执行");
        ctx=new AnnotationConfigApplicationContext(
            Config.class);
    }

    /**
     * After 在XXX之后, JUnit中@After注解的作用是在测试案
     * 例之后执行
     * 用于回收测试之前创建的资源
     * destroy: 销毁
     */
    @After
    public void destroy(){
        //Spring提供了关闭Spring的方法,释放Spring中的对象
        ctx.close();
        System.out.println("释放资源");
    }

    /**
     * 被测试方法前面要标注 @Test
     * 测试方法必须是 公有 无返回值 无参数 的方法
     */
    @Test
    public void hello(){
        System.out.println("Hello World!");
    }

    @Test
    public void demo(){
        System.out.println("Demo");
    }
    /**
     * 测试一下, 如果Spring中相同类型的对象有一个以上时,
     * 按照类型获取对象将出现异常
     */
    @Test
    public void testGetBean(){
        DemoBean demoBean = ctx.getBean(DemoBean.class);
        System.out.println(demoBean);
    }
    @Test
    public void testBeanID(){
        DemoBean demoBean = 
            ctx.getBean("demoBeanX",DemoBean.class);
        System.out.println(demoBean);
    }
}
```

### @Scope

在配置文件中, 使用@Scope("prototype"), Spring按照多个实例管理对象, 每次调用getBean方法, Spring都会创建一个新对象. 

1. 在配置文件中使用 @Scope("prototype")

   ```java
   @Bean
   //Spring按照多个实例管理对象
   @Scope("prototype")
   public DemoBean demoBeanX(){
       return new DemoBean();
   }
   ```

2. 编写测试案例

   ```java
   @Test
   public void testPrototype(){
       /**
        * 在配置中添加 @Scope("prototype")就会创建多个实例
        */
       DemoBean bean1 = ctx.getBean(
           "demoBeanX", DemoBean.class);
       DemoBean bean2 = ctx.getBean(
           "demoBeanX", DemoBean.class);
       DemoBean bean3 = ctx.getBean(
           "demoBeanX", DemoBean.class);
       System.out.println(bean1 == bean2);
       System.out.println(bean1 == bean3);
   }
   ```

关于单例:

-  默认的单例规则管理java bean其优势是性能好, 资源消耗少, 尽量使用默认的单例规则管理对象
- 如果软件业务需要创建多个实例时候就需要添加 @Scope("prototype") 

### 组件扫描

Spring 提供的根据注解自动创建Bean的方式. 这种方式的优势在于可以简化代码, 是开发中最常用的创建Bean对象的方式.

原理:

![image-20210305155504564](image-20210305155504564.png)

案例:

1. 配置

   ```java
   @Configuration
   /**
    * @ComponentScan("cn.tedu.bean") 开启组件扫描功能
    * Spring 启动后会自动扫描 cn.tedu.bean 包和其子包中的
    * 类, 如果类上标注了 @Component 就会在Spring中创建该
    * 类型的对象
    * Component: 组件 
    * Scan : 扫描
    */
   @ComponentScan("cn.tedu.bean")
   public class Config {
   	//... 
   }
   ```

2. 编写JavaBean

   ```java
   package cn.tedu.bean;
   
   import org.springframework.stereotype.Component;
   import java.io.Serializable;
   
   @Component
   public class TestBean implements Serializable {
       @Override
       public String toString() {
           return "Test Bean";
       }
   }
   ```

3. 测试

   ```java
   @Test
   public void testComponentScan(){
       /**
        * 测试组件扫描功能
        */
       TestBean bean = ctx.getBean(TestBean.class);
       System.out.println(bean);
   }
   ```

#### Spring 提供了多种组件注解

- @Component  组件, 用于标注通用
- @Service  服务, 用于标注业务层组件
- @Controller 控制器, 用于标识控制器层组件
- @Repository 仓库, 用于标注数据存储组件
- ... 

在应用软件中按照组件功能, 使用对应注解声明响应的Bean对象, 如果是通用组件使用 @Component 

#### 组件扫描时候的BeanID

- 如果是驼峰命名的类名, BeanID是 类名首字母转换为小写
  - 类 ExampleBean 的BeanID是 exampleBean
- 如果类名连续两个大写字母以上, 则BeanID就是类名本身
  - 类 IExampleBean 的BeanID IExampleBean 
  - 类 MYExampleBean 的BeanID MYExampleBean 

- 可以利用注解参数修改BeanID
  - @Component("test") 的BeanID 是 test

- 在软件开发中尽量使用默认规则!

案例:

```java
@Component
public class MYExampleBean {
    @Override
    public String toString() {
        return "MYExampleBean";
    }
}
```

```java
@Component
public class MYExampleBean {
    @Override
    public String toString() {
        return "MYExampleBean";
    }
}
```

```java
@Test
public void testBeanId(){
    /*
     * 1. 驼峰命名规则
     * 2. 首字母连续大写
     * 3. 自定义BeanID @Component("test")
     */
    String[] names = ctx.getBeanNamesForType(ExampleBean.class);
    for (String name: names){
        System.out.println(name);
    }
    names = ctx.getBeanNamesForType(MYExampleBean.class);
    for (String name: names){
        System.out.println(name);
    }
    names = ctx.getBeanNamesForType(HelloBean.class);
    for (String name: names){
        System.out.println(name);
    }
}
```

#### 懒惰初始化

Spring中默认情况下, 在Spring启动时候立即初始化(创建)单例JavaBean对象. 在使用对象时候, 可以即将得到对象. 

在声明JavaBean时候使用 @Lazy , Spring在启动时候不会创建对象, 直到第一次使用时候才创建对象. 如果一个对象很少使用, 有可能不会使用到, 就应该声明为懒惰!

Lazy : 懒惰

```java
/**
 * Saw 锯
 */
@Component
@Lazy
public class Saw implements Serializable {
    public Saw(){
        System.out.println("创建了Saw");
    }

    @Override
    public String toString() {
        return "电锯";
    }
}
```

```java
@Test
public void testLazy(){
    /*
     * 测试懒惰初始化
     */
    HelloBean helloBean =
            ctx.getBean(HelloBean.class);
    System.out.println(helloBean);
    //第一次使用getBean(Saw.class)时候
    //才创建Saw对象
    Saw saw = ctx.getBean(Saw.class);
    System.out.println(saw);
}
```



### 利用Spring管理数据库连接池

1. 导入Druid 连接池和数据库驱动
2. 利用Spring创建连接池对象
3. 设置连接参数 
4. 测试连接

```xml
<!-- 连接MySQL数据库的依赖 -->
<dependency>
    <groupId>mysql</groupId>
    <artifactId>mysql-connector-java</artifactId>
    <version>8.0.15</version>
</dependency>
<!-- 数据库连接池 -->
<dependency>
    <groupId>com.alibaba</groupId>
    <artifactId>druid</artifactId>
    <version>1.1.21</version>
</dependency>
```

```java
@Bean
public DruidDataSource dataSource(){
    DruidDataSource dataSource =
            new DruidDataSource();
    //最新版的JDBC驱动可以自动注册, 可以不写驱动类名
    //dataSource.setDriverClassName();
    dataSource.setUrl("jdbc:mysql://localhost:3306/mysql?characterEncoding=utf8&useSSL=false&serverTimezone=Asia/Shanghai&rewriteBatchedStatements=true");
    dataSource.setUsername("root");
    dataSource.setPassword("root");
    return dataSource;
}
```

```java
@Test
public void testDataSource() throws Exception{
    DruidDataSource dataSource =
            ctx.getBean(DruidDataSource.class);
    Connection connection = dataSource.getConnection();
    System.out.println(connection);
    connection.close();
}
```

## 作业

1. 重新创建Spring项目，重新编写全部课堂案例
2. @Bean练习
   1. 编写一个类 Saw（锯）
   2. 在配置类Config中利用@Bean创建Saw类型的Bean对象
   3. 在测试案例中getBean获得Saw类型的Bean对象
   4. 在测试案例中检查Saw类型的Bean对象的BeanID

1. @Component 练习
   1. 编写一个类 Worker（工人）
   2. 使用@Component 声明JavaBean
   3. 在配置类中标注 @ComponentScan
   4. 测试案例中测试JavaBean 和 BeanID
2. 重新编写@Bean管理数据库连接池的案例。

 



