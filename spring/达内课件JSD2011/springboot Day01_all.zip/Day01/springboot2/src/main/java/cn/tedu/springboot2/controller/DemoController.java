package cn.tedu.springboot2.controller;

import cn.tedu.springboot2.bean.User;
import lombok.extern.slf4j.Slf4j;
import org.omg.PortableInterceptor.INACTIVE;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * @Controller 注解用于标注用于处理浏览器请求的类
 */
@Controller
//@Slf4j
public class DemoController {

    //如果不使用 @Slf4j 则使用下面代码替代, 结果完全一样
    private static Logger log =
            LoggerFactory.getLogger(DemoController.class);

    /**
     * @RequestMapping 注解用于声明, 当前方法处理那个
     * 浏览器请求!
     * 当前浏览器请求 http://localhost:8080/test 时候
     * 就执行 test() 方法
     * @ResponseBody 将方法的返回值填充响应消息的Body(正文)中
     *  响应正文信息会发送到浏览器中显示出来
     * @return
     */
    @RequestMapping("/test")
    @ResponseBody
    public String test(){
        //在服务器的控制台上显示 Hello World
        log.debug("Hello World!");
        return "Hello World!";
    }

    /**
     * 请求路径: http://localhost:8080/user
     * @return
     */
    @RequestMapping("/user")
    @ResponseBody
    public User demo(){
        User user = new User().setId(1).setName("Tom").setAddress("北京")
                .setScores(new int[]{2,3,6,8,10});
        //标注了@ResponseBody以后, 如果方法返回是Java bean 就会转换为JSON
        //添加到 HTTP 响应的正文中发送到浏览器, 一般用于处理AJAX请求
        log.debug("user:{}", user);
        return user;
    }

    /**
     * 利用控制器方法参数, 接收表单参数,
     * 参数名与表单参数的name属性一致
     * 对于特殊情况, 使用@RequestParam映射参数
     * @return
     */
    @RequestMapping("/add")
    @ResponseBody
    public String add(
            @RequestParam String username,
            @RequestParam Integer age,
            @RequestParam("if")String str){
        log.debug("接收到: {}, {}, {}", username, age, str);
        return "添加完成";
    }

}







