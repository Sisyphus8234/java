# Spring Boot

## 什么是SpringBoot

SpringBoot是Spring框架的快速搭建脚手架, 可以快速创建Spring应用, 创建以后几乎不用配置, 就可以直接启动运行.

- SpringBoot 项目内嵌了 Spring默认配置类
- SpringBoot 项目内嵌了组件扫描
- SpringBoot 项目内嵌了 测试框架
- ...

## 使用SpringBoot

开发工具 IDEA 内嵌了SpringBoot的搭建功能. 这些搭建功能底层依赖与脚手架网站(模板网站) 

- https://start.spring.io/
- https://start.aliyun.com/

### 创建SpringBoot项目

1. 利用开发工具常见SpringBoot项目

   ![image-20210309091949302](image-20210309091949302.png)

   ![image-20210309092254009](image-20210309092254009.png)

   ![image-20210309092614424](image-20210309092614424.png)

   ![image-20210309092651424](image-20210309092651424.png)

2. SpringBoot 项目介绍

   ![image-20210203095617305](image-20210203095617305.png)
   
   - 已经配置的JDK版本
   - 由于继承了spring-boot-starter-parent, 就自动继承了依赖的包
   - 由于自动添加了spring-boot-starter-test依赖, 就自动配置了测试工具
   - 添加了spring-boot-maven-plugin打包工具
   - SpringBoot项目提供了包含main方法启动类 XXXApplication, XXX就是项目名称, 使用这个类可以启动程序
  - XXXApplication 即是启动类, 也是Spring的配置文件类, 可以使用@Bean等注解声明JavaBean对象
     - XXXApplication 自动启动组件扫描, 扫描当前包和其子包中的注解.
   - SpringBoot项目提供了测试类Springboot1ApplicationTests, 将被测试组件注入到测试类就可以进行测试了.

### Hello World!

- 在启动类的子包中创建 JavaBean类型, 添加@Component注解

  ```java
  package cn.tedu.springboot1.bean;
  
  import org.springframework.stereotype.Component;
  
  import java.io.Serializable;
  @Component
  public class DemoBean
          implements Serializable {
      @Override
      public String toString() {
          return "Hello World!";
      }
  }
  ```

- 将JavaBean注入到测试类Springboot1ApplicationTests中 @Resource

- 在测试方法中输出JavaBean

  ```java
  /**
   * SpringBoot 整合了JUnit5
   * 1. 测试类需要和启动类在相同的包
   * 2. 需要标注@SpringBootTest
   * 3. 可以注入Spring中的JavaBean对象
   * 4. 测试类和方法，可以不是 public 的
   */
  @SpringBootTest
  class Springboot1ApplicationTests {
      @Resource
      DemoBean demoBean;
      @Test
      void contextLoads() {
          System.out.println(demoBean);
      }
  }
  ```

  

### 创建SpringBoot项目的常见问题解决

- 如果 Spring 脚手架网站不能访问就换成 阿里云脚手架网站
- 由于SpringBoot导入的包很多, 多达100MB以上, 文件数量多, 有下载失败的可能性, 其表现为各种红线!
- 解决办法:
  1. 检查是否配置了境内的maven仓库: 将包含阿里云或者华为云仓库连接的settings.xml文件放到 用户/.m2文件夹.
  2. 删除Maven本地仓库文件夹, 用户/.m2/repository
  3. 重新打开 IDEA, Maven->Reload All Maven Projects

### 测试 SpringBoot DI功能



## Lombok

是可以简化Java开发的工具, 安装插件以后, 开发工具会在编译期间根据注解自动为Java类添加get set 构造器等方法.

> 注意: 需要在开发工具中添加插件才能使用 Lombok 

Lombok 注解:

- @Getter 在类上添加get方法
- @Setter 在类上添加set方法
- @ToString 在类上添加 toString 方法
- @EqualsAndHashCode 在类上添加 equals 和 hashCode 方法

- @Data 添加到类以后, 自动添加 get set方法, 自动添加 toString 自动添加equals hashCode. 

  - @Data = @Getter + @Setter + @ToString + @EqualsAndHashCode

- @AllArgsConstructor 添加全部属性的构造器

- @NoArgsConstructor  添加无参数构造器

-  @Accessors(chain = true) 实现Set方法的链式写法

  ``` java
  //一般的set 方法
  viod setName(String name){
      this.name = name;
  }
  //链式Set方法
  User setName(String name){
      this.name = name;
      return this;
  }
  ```

- @Slf4j 使用日志工具: 在当前类中插入输出日志的对象

案例:

1. 导入Lombok:

```xml
<!-- 添加 Lombok 组件, 不需要添加版本号, Spring Boot
         父级别项目已经统一管理了 Lombok 的版本号-->
<dependency>
    <groupId>org.projectlombok</groupId>
    <artifactId>lombok</artifactId>
</dependency>
```

2. 创建类 使用Lombok 注解

```java
@Data
@NoArgsConstructor  //无参数构造器
@AllArgsConstructor //全部参数构造器
@Accessors(chain = true)
public class User {
    private Integer id;
    private String name;
}
```

3. 测试:

```java
@Test
void testLombok(){
    User user1 = new User();
    user1.setId(1);
    user1.setName("Tom");
    System.out.println(
        user1.getId() +", " + user1.getName());
    System.out.println(user1);//自动调用toString
    User user2 = new User();
    user2.setId(1);
    user2.setName("Tom");
    System.out.println(user1.equals(user2));
    User user = new User(2, "Jerry");
    System.out.println(user);
    //利用链式API(函数式编程)创建对象, 可读性更好,
    // 更方便维护,更不容易错误, 可以无序赋值
    User user3 = new User().setName("熊大").setId(5);
    System.out.println(user3);
}
```

### Lombok 提供了日志注解

案例: 

1. 在测试类上添加 @Slf4j注解

   ```
   @Slf4j //Lombok 提供的日志工具, 添加以后当前类中就有了log对象
   ```

2. 使用log输出信息:

   ```java
   @Test
   void logTest(){
   	log.debug("Hello World!");
   }
   ```

3. 在SpringBoot配置文件中打开日志输出

   ```properties
   # 打开日志输出
   # 打开 cn.tedu.springboot1 包和其子包的日志输出
   logging.level.cn.tedu.springboot1=debug
   ```

4. 测试

使用日志重构 案例:

```java
public interface Tool {
}
```

```java
@Component
@Data
@Accessors(chain = true)
public class Axe implements Serializable, Tool {
    private String name = "开天斧";
}
```

```java
@Component("tool")
@Data
@Accessors(chain = true)
public class Saw implements Serializable, Tool {
    private String name = "寒冰锯";
}
```

```java
@Component
@Data
@Accessors(chain = true)
@Slf4j
public class Worker implements Serializable {
    private String name = "光头强";
    @Resource
    private Tool tool;
    public void work(){
        //System.out.println(name + "使用" + tool + "砍树!");
        log.debug("{}使用{}砍树", name, tool);
        //{}是日志输出的占位符号, 输出时候后面参数按照顺序进行替换
    }
}
```

### SpringBoot 集成了Tomcat服务器

SpringBoot可以0配置使用Tomcat!

在创建SpringBoot项目时候, 选择Web组件, 就会自动安装配置Tomcat!

![image-20210309143604257](image-20210309143604257.png)

# Spring MVC

## 什么是SpringMVC

Spring MVC 也被称为 Spring Web MVC

Spring 提供的 MVC 模式的Web编程框架, 其内部将Web编程的常用功能都封装好了, 使用Spring MVC可以大大简化项目的开发过程. 使用时候:添加控制器, 添加模板,就可以快速编写Web应用. 

Spring MVC 封装了: 

- 接收表单参数
- 处理网页模板
- 根据用户请求调用对应的控制器, 也称为 "路由" 
- ... 等等

### Spring MVC Hello World

编写写步骤:

1. 创建SpringBoot WEB项目, 其内部自动包含了 Spring MVC
2. 编写控制器处理浏览器请求
   1. @Controller 声明控制器组件
   2. @RequestMapping 映射用户请求
   3. @ResponseBody处理响应正文的内容

案例:

```java
/**
 * @Controller 注解用于标注用于处理浏览器请求的类
 */
@Controller
@Slf4j
public class DemoController {

    /**
     * @RequestMapping 注解用于声明, 当前方法处理那个
     * 浏览器请求!
     * 当前浏览器请求 http://localhost:8080/test 时候
     * 就执行 test() 方法
     * @ResponseBody 将方法的返回值填充响应消息的Body(正文)中
     *  响应正文信息会发送到浏览器中显示出来
     * @return
     */
    @RequestMapping("/test")
    @ResponseBody
    public String test(){
        //在服务器的控制台上显示 Hello World
        log.debug("Hello World!");
        return "Hello World!";
    }
}
```

启动, 测试:

![image-20210309160647771](image-20210309160647771.png)

注解:

- @Controller : 标注在控制器类上, 用于配合组件扫描,在Spring中创建对象.

- @RequestMapping: 定义请求路径, 可以标注在控制器类和控制方法上

  - 标注在控制器类和方法上的RequestMapping参数复合在一起形成多级路径

    ```java
    @RequestMapping("user")
    class UserController{
        //login方法的请求路径: /user/login
        @RequestMapping("login")
        public String login(){
            //...
        }
    }
    ```

- @ResponseBody: 标注在控制器方法上, 标注后Spring会自动利用一系列消息转换处理器, 将方法返回值处理以后, 填充到 HTTP响应的正文发送到浏览器.

  - 控制器方法返回字符串, 字符串就直接填充到HTTP响应正文中
  - 如果控制器方法返回了Java Bean对象, Spring就会自动将Java Bean转换为 JSON, 填充到HTTP响应正文中, 用于配合Ajax请求.
  - ... 

返回JSON案例:

```java
package cn.tedu.springboot2.bean;

import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;
@Data
@Accessors(chain = true)
public class User implements Serializable {
    private Integer id;
    private String name;
    private String address;
    private int[] scores;
}
```

控制器:

```java
/**
* 请求路径: http://localhost:8080/user
* @return
*/
@RequestMapping("/user")
@ResponseBody
public User demo(){
    User user = new User().setId(1).setName("Tom")
        .setAddress("北京")
        .setScores(new int[]{2,3,6,8,10});
    //标注了@ResponseBody以后, 如果方法返回是
    // Java bean 就会转换为JSON
    // 添加到 HTTP 响应的正文中发送到浏览器, 一般用于处理AJAX请求
    log.debug("user:{}", user);
    return user;
}
```

测试... http://localhost:8080/user

### Spring MVC如何接收表单参数

Spring MVC封装了接收表单参数

- 只需要将控制器参数与表单参数对应起来就可以接收表单参数了. 
- 如果特殊属性, 比如和Java关键字冲突, 可以使用 @RequestParam映射

@RequestParam() 用于映射特殊表单参数

@RequestParam() 默认情况是必须输入的参数, 如果不添加将出现异常

为了保证所有表单项目都是必须输入的, 则在变量上都添加@RequestParam

原理:

![image-20210309175408732](image-20210309175408732.png)

案例:

```html
<!DOCTYPE html>
<html lang="cn">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
    <h1>添加信息</h1>
    <form method="post" action="/add">

        <div>
            <label>名字:</label>
            <input type="text" name="username">
        </div>

        <div>
            <label>年龄</label>
            <input type="number" name="age">
        </div>

        <div>
            <label>条件</label>
            <input type="text" name="if">
        </div>
        <button type="submit">提交</button>
    </form>
</body>
</html>
```

```java
/**
* 利用控制器方法参数, 接收表单参数,
* 参数名与表单参数的name属性一致
* 对于特殊情况, 使用@RequestParam映射参数
* @return
*/
@RequestMapping("/add")
@ResponseBody
public String add(
    @RequestParam String username,
    @RequestParam Integer age,
    @RequestParam("if")String str){
    log.debug("接收到: {}, {}, {}", username, age, str);
    return "添加完成";
}
```









