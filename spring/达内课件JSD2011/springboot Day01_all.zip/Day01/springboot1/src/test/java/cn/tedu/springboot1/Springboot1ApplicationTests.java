package cn.tedu.springboot1;

import cn.tedu.springboot1.bean.DemoBean;
import cn.tedu.springboot1.bean.User;
import cn.tedu.springboot1.bean.Worker;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import javax.annotation.Resource;

/**
 * SpringBoot 整合了JUnit5
 * 1. 测试类需要和启动类在相同的包
 * 2. 需要标注@SpringBootTest
 * 3. 可以注入Spring中的JavaBean对象
 * 4. 测试类和方法，可以不是 public 的
 */
@SpringBootTest
@Slf4j //Lombok 提供的日志工具, 添加以后当前类中就有了log对象
class Springboot1ApplicationTests {
    @Resource
    DemoBean demoBean;
    @Resource
    Worker worker;
    @Test
    void contextLoads() {
        System.out.println(demoBean);
    }
    @Test
    void testWorker(){
        worker.work();
    }

    @Test
    void testLombok(){
        User user1 = new User();
        user1.setId(1);
        user1.setName("Tom");
        //System.out.println(user1.getId() +", " + user1.getName());
        log.debug("{},{}", user1.getId(), user1.getName());
        //System.out.println(user1);//自动调用toString
        log.debug("User1:{}", user1);
        User user2 = new User();
        user2.setId(1);
        user2.setName("Tom");
        //System.out.println(user1.equals(user2));
        log.debug("user1.equals(user2):{}", user1.equals(user2));
        User user = new User(2, "Jerry");
        //System.out.println(user);
        log.debug("user: {}", user);
        //利用链式API(函数式编程)创建对象, 可读性更,
        // 更方便维护,更不容易错误, 可以无序赋值
        User user3 = new User().setName("熊大").setId(5);
        //System.out.println(user3);
        log.debug("user3: {}", user3);
        log.debug("Hello World!");
    }

    @Test
    void logTest(){
        log.debug("Hello World!");
    }
}
