package cn.tedu.springboot1.bean;

public interface Tool {
}
