# Spring MVC

Model: 负责处理业务, 处理数据, 处理软件的核心功能, Java程序编写

View: 视图, 用于展示业务处理结果

Controller: 控制器, 接收视图界面发送的请求, 将请求交给Model进行处理, 根据处理结果选择界面显示. 

Spring MVC中的M需要自己写, 实际上只有Spring VC.

## 控制器接收表单Post请求数据

将表单中input元素的name属性值与控制器方法参数名对应起来, 就可以在控制器接收到表单参数.

## 控制器接收get请求数据

将get请求参数名称和控制器参数名称对应起来就可以接收get请求参数. 

原理:

![image-20210310120153609](image-20210310120153609.png)

编写控制器类:

```java
@Controller
@Slf4j
public class TestController {
    /**
     * method = RequestMethod.GET 表示只处理get请求,
     * 其他请求方式, 出现 405 错误, 不支持的请求方式
     * path = "/getuser" 表示映射的请求路径
     * 完整请求路径: 
     * http://localhost:8080/getuser?id=1&name=Tom&name=Jerry&name=Andy
     * 如果请求中发送了多个名字相同的参数, 则使用数组映射接收参数
     */
    @RequestMapping(method = RequestMethod.GET,
            path = "/getuser")
    @ResponseBody
    public String getUser(Integer id, String[] name){
        //处理get请求发送的参数
        log.debug("收到信息:{},{}", id, name);
        return "处理了/getuser";
    }
}
```

测试:  http://localhost:8080/getuser?id=1&name=Tom&name=Jerry&name=Andy

控制台查看结果

关于 @RequestMapping 

- 默认的 @RequestMapping 可以映射任何请求方式, 包括个GET POST 等
- 使用 @RequestMapping(method = RequestMethod.POST) 只处理POST请求
- 使用 @RequestMapping(method = RequestMethod.GET) 只处理GET请求
-  @RequestMapping(method = RequestMethod.POST)  = @PostMapping()
-  @RequestMapping(method = RequestMethod.GET)  = @GetMapping()

### 利用JavaBean封装请求参数

如果请求参数很多, 利用控制器方法参数接收就会显得很啰嗦, Spring提供了将一组参数封装到JavaBean的处理方式:

![image-20210310120728984](image-20210310120728984.png)

案例

JavaBean

```java
/**
 * Spring 在利用JavaBean传递参数时候,
 * 会调用get set方法进行赋值, 传递
 * 参数, 如果JavaBean没有get set 方法
 * 则无法传递参数
 */
@Data
@Accessors(chain = true)
public class User implements Serializable {
    private Integer id;
    private String[] name;
    //...
}
```

控制器

```java
    /**
     * 利用JavaBean封装接收get请求参数
     * @param user
     * @return
     */
    @RequestMapping(method = RequestMethod.GET, 
                    path = "/getuser1")
    @ResponseBody
    public String getUser1(User user){
        log.debug("表单信息:{}", user);
        return "利用JavaBean接收参数";
    }
```

测试:

测试:  http://localhost:8080/getuser?id=1&name=Tom&name=Jerry&name=Andy

控制台查看结果

### 利用javaBean处理Post表单参数

案例 demo.html

```html
<!DOCTYPE html>
<html lang="zh">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
    <h1>处理POST请求</h1>
    <form action="/getuser2" method="post">
        <div>
            <label>编号</label><input type="number" name="id">
        </div>
        <div>
            <label>名字</label>
            <input type="text" name="name">
            <input type="text" name="name">
            <input type="text" name="name">
        </div>
        <button type="submit">提交</button>
    </form>
</body>
</html>
```

控制器方法:

```java
/**
 * @PostMapping =
 * @RequestMapping(method = RequestMethod.POST)
 * @param user
 * @return
 */
@PostMapping("/getuser2")
@ResponseBody
public String getUser2(User user){
    log.debug("表单信息:{}", user);
    return "利用JavaBean接收参数";
}
```



## 在控制中直接注入 request response session 对象

在控制器方法上可以注入   request response session 对象, 就可以直接调用原生的 Servlet API, 处理WEB请求. 如: 获取客户端的IP地址. 

案例

```java
/**
 * 使用原生的 Servlet API 检查用户IP
 * @return
 */
@GetMapping("/test")
@ResponseBody
public String test(
        HttpServletRequest request,
        HttpServletResponse response,
        HttpSession session){
    //.getRemoteAddr() 在服务器端获取客户端的IP
    String ip =  request.getRemoteAddr();
    log.debug("客户端地址:{}", ip);
    return "客户端:"+ip;
}
```

## 控制器接收参数

- 如果参数比较少, 就直接使用 控制器方法参数接收
  - @RequestParam 处理特殊参数名
- 如果参数很多, 就定义一个JavaBean接收一批参数
  - 定义参数名称时候要规避特殊关键字
- POST请求可以使用如下方式处理:
  - @RequestMapping()
  - @RequestMapping(method=RequestMethod.POST)
  - @PostMapping
- GET 请求可以使用如下方式处理:
  - @RequestMapping()
  - @RequestMapping(method=RequestMethod.GET)
  - @GetMapping
- 如果需要访问ServletAPI, 就直接在控制器方法参数上注入 request, response, session

## 利用模板显示结果

利用View 模板显示结果到界面.  目前显示方式有两种方式: 

- 服务端模板: 是利用Thymeleaf 模板引擎, 在服务器端生成HTML页面, 响应到浏览器显示数据
- 前后端分离: 利用Ajax将数据发送到客户端浏览器, 在浏览器中局部更新HTML页面显示数据

### 服务端视图模板显示数据

SpringBoot 默认的视图模板就是Thymeleaf.

![image-20210310121352466](image-20210310121352466.png)

使用步骤:

1. 导入Thymeleaf模板包
2. 页面模板存储路径 resources/templates 
3. 控制器如果不添加 @ResponseBody时候, 默认返回是模板名称
   - 模板名称:  模板文件名 去掉.html 
   - 控制器返回模板名称后, Spring 就会找到模板, 在服务器上进行渲染, 显示到浏览器中

导入Thymeleaf

```xml
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-thymeleaf</artifactId>
</dependency>
```

添加模板 resources/templates

```html
<!DOCTYPE html>
<html lang="cn">
<head>
    <meta charset="UTF-8">
    <title>Title</title>
</head>
<body>
    <h1>Hello World!</h1>
</body>
</html>
```

控制器

```java
/**
 * 显示 hello.html 模板
 * 不要添加 @ResponseBody
 */
@GetMapping("/demo")
public String demo(){
    //控制器方法返回的是模板名称!
    // spring 会自动 匹配到 hello.html
    log.debug("执行了demo()");
    return "hello";
}
```

## 转发与重定向





