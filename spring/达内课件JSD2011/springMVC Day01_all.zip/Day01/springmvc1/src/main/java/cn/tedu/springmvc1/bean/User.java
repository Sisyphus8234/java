package cn.tedu.springmvc1.bean;

import lombok.Data;
import lombok.experimental.Accessors;

import java.io.Serializable;

/**
 * Spring 在利用JavaBean传递参数时候,
 * 会调用get set方法进行赋值, 传递
 * 参数, 如果JavaBean没有get set 方法
 * 则无法传递参数
 */
@Data
@Accessors(chain = true)
public class User implements Serializable {
    private Integer id;
    private String[] name;
    //...
}
