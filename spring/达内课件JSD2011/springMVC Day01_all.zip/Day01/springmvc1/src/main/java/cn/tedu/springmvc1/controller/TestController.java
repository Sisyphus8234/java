package cn.tedu.springmvc1.controller;

import cn.tedu.springmvc1.bean.User;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.servlet.http.MappingMatch;
import java.util.Map;

@Controller
@Slf4j
public class TestController {
    /**
     * method = RequestMethod.GET 表示只处理get请求,
     * 其他请求方式, 出现 405 错误, 不支持的请求方式
     * path = "/getuser" 表示映射的请求路径
     * 完整请求路径: http://localhost:8080/getuser?id=1&name=Tom&name=Jerry&name=Andy
     * 如果请求中发送了多个名字相同的参数, 则使用数组映射接收参数
     */
    @RequestMapping(method = RequestMethod.GET,
            path = "/getuser")
    @ResponseBody
    public String getUser(Integer id, String[] name){
        //处理get请求发送的参数
        log.debug("收到信息:{},{}", id, name);
        return "处理了/getuser";
    }

    /**
     * 利用JavaBean封装接收get请求参数
     * @param user
     * @return
     */
    @RequestMapping(method = RequestMethod.GET, path = "/getuser1")
    @ResponseBody
    public String getUser1(User user){
        log.debug("表单信息:{}", user);
        return "利用JavaBean接收参数";
    }

    /**
     * @PostMapping =
     * @RequestMapping(method = RequestMethod.POST)
     * @param user
     * @return
     */
    @PostMapping("/getuser2")
    @ResponseBody
    public String getUser2(User user){
        log.debug("表单信息:{}", user);
        return "利用JavaBean接收参数";
    }

    /**
     * 使用原生的 Servlet API 检查用户IP
     * @return
     */
    @GetMapping("/test")
    @ResponseBody
    public String test(
            HttpServletRequest request,
            HttpServletResponse response,
            HttpSession session){
        //.getRemoteAddr() 在服务器端获取客户端的IP
        String ip =  request.getRemoteAddr();
        log.debug("客户端地址:{}", ip);
        return "客户端:"+ip;
    }

    /**
     * 显示 hello.html 模板
     * 不要添加 @ResponseBody
     */
    @GetMapping("/demo")
    public String demo(){
        //控制器方法返回的是模板名称!
        // spring 会自动 匹配到 hello.html
        log.debug("执行了demo()");
        return "hello";
    }

    /**
     * 在模板中显示信息
     */
    @GetMapping("/viewdemo")
    public ModelAndView viewDemo(){
        //创建 ModelAndView 对象
        ModelAndView mv = new ModelAndView();
        //在mv中添加视图模板名称 "message"
        mv.setViewName("message");
        // 在mv中添加需要显示的数据
        mv.addObject("msg", "Hello");
        mv.addObject("user", "Tom");
        return mv;
    }

    /**
     * 利用ModelMap传递数据
     * 将需要在视图上显示的数据, 添加到map中
     * 方法返回值是视图名称
     * ModelMap 是 Map 接口子类型
     * 可使用Map作为参数类型, 结果完全一样
     * 考虑到 ModelMap 比 Map 有更明确的
     * 业务意义, 可以考虑使用 ModelMap
     */
    @GetMapping("/viewdemo2")
    public String viewDemo2(Map<String, Object> map){
        map.put("msg", "OK");
        map.put("user", "Wang");
        return "message";
    }

    /**
     * 测试Spring MVC提供的服务端重定向功能
     * 重定向:
     *   支持绝对地址重定向, 在网站直接重定向
     *   相对地址重定向, 在当前网站内部重定向
     */
    @GetMapping("/doc")
    public String doc(){
        log.debug("/doc");
        return "redirect:http://doc.canglaoshi.org";
    }

    @GetMapping("/hello")
    public String hello(){
        //重定向到当前网站
        return "redirect:/viewdemo2";
    }

    /**
     * 控制器标注了@ResponseBody以后,
     * 如果控制器返回javaBean 对象
     * Spring MVC就会将java bean转换
     * 为JSON并且返回给浏览器
     */
    @GetMapping("/json")
    @ResponseBody
    public User json(){
        User user = new User().setId(1)
                .setName(new String[]{"Tom", "Jerry"});
        return user;
    }

}
