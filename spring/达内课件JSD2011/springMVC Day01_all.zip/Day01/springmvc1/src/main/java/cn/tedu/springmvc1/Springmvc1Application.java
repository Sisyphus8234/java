package cn.tedu.springmvc1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Springmvc1Application {

    public static void main(String[] args) {
        SpringApplication.run(Springmvc1Application.class, args);
    }

}
