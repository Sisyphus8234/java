//package aaa;
//
//import org.apache.ibatis.annotations.Select;
//
//
//public interface aaaMapper {
//
//
//    @Select("SELECT ID_ FROM act_ru_identitylink where TASK_ID_ = #{id}")
//    String aaa1(String id);
//}
