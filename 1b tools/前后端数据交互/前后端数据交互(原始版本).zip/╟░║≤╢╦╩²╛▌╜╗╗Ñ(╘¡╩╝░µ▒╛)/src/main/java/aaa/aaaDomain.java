package aaa;

public class aaaDomain {

    String name;

    aaaDomain2 aaaDomain2;

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public aaaDomain2 getAaaDomain2() {
        return aaaDomain2;
    }

    public void setAaaDomain2(aaaDomain2 aaaDomain2) {
        this.aaaDomain2 = aaaDomain2;
    }
}
