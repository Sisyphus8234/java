package cn.tedu.mybatis1.mapper;

import cn.tedu.mybatis1.entity.Employee;
import org.apache.ibatis.annotations.*;

import java.util.List;

/**
 * Employee 的数据访问接口
 */
public interface EmployeeMapper {
    /**
     * 根据ID查询一个员工数据
     * #{empNo} 是MyBatis的参数占位符,
     * 在查询时候, MyBatis会读取方法参数
     * 作为占位的参数传输到数据库执行SQL
     *
     * 如果查询结果中的列名和实体类属性不
     * 一致, 可以使用设置列别名方式, 将查询
     * 结果列与实体类的属性名对应上
     */
    //@Select("SELECT * FROM emp WHERE EMPNO=#{empNo}")
    @Select({"SELECT ",
            "empNo," ,
            "ename AS name," ,
            "job,",
            "mgr, ",
            "hiredate, ",
            "sal AS salary,",
            "comm,",
            "deptNo",
            "FROM emp WHERE EMPNO=#{empNo}"})
    Employee getEmployeeById(Integer empNo);

    /**
     * 将全部的员工信息查询出来
     */
    @Select({"SELECT ",
            "empNo," ,
            "ename AS name," ,
            "job,",
            "mgr, ",
            "hiredate, ",
            "sal AS salary,",
            "comm,",
            "deptNo",
            "FROM emp"})
    List<Employee> getAllEmployee();

    /**
     * 利用MyBatis将员工数据插入到数据中
     * INSERT INTO emp
     *     (EMPNO, ENAME, JOB, MGR, HIREdate, SAL, COMM, DEPTNO)
     *     VALUES
     *     (null, 'Tom', 'Coding', 0, now(), 1000.0, 100.0, 1)
     *
     * 参数: #{name}表示读取employee对象的name属性
     */
    @Insert({"INSERT INTO emp",
            "(EMPNO, ENAME, JOB, MGR, HIREdate, SAL, COMM, DEPTNO)",
            "VALUES",
            "(null, #{name}, #{job}, #{mgr}, #{hiredate},",
            "#{salary}, #{comm}, #{deptNo})"})
    /**
     * Options: 选项
     * Generated: 生成的
     * Keys: 关键字
     * keyProperty: 关键字属性, 就是实体类中的ID
     * 标注了@Options()可以与 @Insert配合获取自动生成的 Key
     * keyProperty = "empNo" 中的empNo是Employee的属性
     */
    @Options(useGeneratedKeys = true, keyProperty = "empNo")
    Integer saveEmployee(Employee employee);

    /**
     * 根据ID更新一个员工的全部信息
     * UPDATE emp
     * SET ENAME=?, JOB=?, MGR=?, HIREdate=?,
     *     SAL=?, COMM=?, DEPTNO=?
     * WHERE EMPNO=?;
     * MyBatis的Mapper方法, 如果执行的是
     * INSERT UPDATE DELETE 则可以返回一个
     * 整数结果, 表示插入\更新\删除的行数
     */
    @Update({"UPDATE emp",
            "SET ENAME=#{name}, JOB=#{job}, MGR=#{mgr}, HIREdate=#{hiredate},",
            "    SAL=#{salary}, COMM=#{comm}, DEPTNO=#{deptNo}",
            "WHERE EMPNO=#{empNo}"})
    Integer updateEmployee(Employee employee);

    /**
     * 删除 一行 数据
     * DELETE FROM emp WHERE EMPNO=?
     */
    @Delete("DELETE FROM emp WHERE EMPNO=#{empNo}")
    Integer deleteEmployeeById(Integer empNo);

    /**
     * 查询 薪资介于2000到2200之间的员工
     * X BETWEEN A AND B : X 介于 A 和 B 之间
     * SELECT * FROM emp WHERE SAL BETWEEN 2000 AND 2200
     */
    /**
     * 关于参数名称:
     * 1. Java 8 之前Java编译以后, 在字节码文件中不保留
     *    方法参数变量名. 为了处理对个参数变量, MyBatis
     *    提供了一个注解, @Param("min") 作用就是给参数
     *    方法参数变量一个名称, 用于SQL语句参数绑定
     * 2. Java 8 以后SpringBoot在Maven插件中开启保留
     *    Java方法参数名到字节码文件的功能. Java 8 +
     *    SpringBoot 时候, 可以不用使用@Param("min")
     * 3. 利用阿里云脚手架创建的SpringBoot项目, 没有
     *    打开这个开关, 按照1进行编译.
     */
    @Select({"SELECT ",
            "empNo," ,
            "ename AS name," ,
            "job,",
            "mgr, ",
            "hiredate, ",
            "sal AS salary,",
            "comm,",
            "deptNo",
            "FROM emp",
            "WHERE SAL BETWEEN #{min} AND #{max}",
            "ORDER BY SAL DESC"})
    List<Employee> getEmployeeBySalary(
            @Param("min") Double min, @Param("max") Double max);

}
