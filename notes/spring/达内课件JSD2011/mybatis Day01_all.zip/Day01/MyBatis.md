# MyBatis

MyBatis 是一款优秀的持久层框架。MyBatis 免除了几乎所有的 JDBC 代码以及设置参数和获取结果集的工作。大大简化了数据访问开发代码量. 

持久层: 软件中负责将数据长久保存的代码层, 其核心功能就是 CRUD.

CRUD: C创建增加, R寻回查找, U更新修改, D删除, 增删改查.

简单理解: 可以自动完成JDBC CRDU编码, 提升开发效率. 

## 使用MyBatis

1. 导入包
   - MyBatis 原生包, 导入以后需要进行适当配置才能使用, 时候独立使用MyBatis. 
   - MyBatis-SpringBoot starter 包, 导入到SpringBoot后几乎不需要配置.需要配置JDBC连接参数就可以了. 

2. 配置JDBC参数

3. 编写数据库访问接口 XxxMapper

   1. 在接口定义数据库访问方法以及对应的SQL语句

      ```java
      @Select("SELECT 'hello world!'")
      String hello();
      ```

4. 在配置类中开启Mapper接口扫描, 自动创建Mapper接口的匿名子类实例.这些对象都放在Spring容器中.

5. 测试, 将Mapper注入到测试类, 调用方法进行测试.

![image-20210311175418699](image-20210311175418699.png)



创建项目导入MyBatis SpringBoot Starter 和 JDBC驱动

```xml
<dependency>
    <groupId>org.mybatis.spring.boot</groupId>
    <artifactId>mybatis-spring-boot-starter</artifactId>
    <version>2.1.4</version>
</dependency>
<dependency>
    <groupId>mysql</groupId>
    <artifactId>mysql-connector-java</artifactId>
    <scope>runtime</scope>
</dependency>
<dependency>
    <groupId>org.projectlombok</groupId>
    <artifactId>lombok</artifactId>
    <optional>true</optional>
</dependency>
```

配置

```
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-thymeleaf</artifactId>
</dependency>
<dependency>
    <groupId>org.springframework.boot</groupId>
    <artifactId>spring-boot-starter-web</artifactId>
</dependency>
<dependency>
    <groupId>org.mybatis.spring.boot</groupId>
    <artifactId>mybatis-spring-boot-starter</artifactId>
    <version>2.1.4</version>
</dependency>

<dependency>
    <groupId>mysql</groupId>
    <artifactId>mysql-connector-java</artifactId>
    <scope>runtime</scope>
</dependency>
<dependency>
    <groupId>org.projectlombok</groupId>
    <artifactId>lombok</artifactId>
    <optional>true</optional>
</dependency>
```

配置

```properties
spring.datasource.driver-class-name=com.mysql.cj.jdbc.Driver
spring.datasource.url=jdbc:mysql://localhost:3306/demo?characterEncoding=utf8&useSSL=false&serverTimezone=Asia/Shanghai&rewriteBatchedStatements=true
spring.datasource.username=root
spring.datasource.password=root

# 开启日志输出
logging.level.cn.tedu.mybatis1=debug
# 开始Mapper接口的日志, 可看到SQL语句的执行过程
logging.level.cn.tedu.mybatis1.mapper=debug
```

添加Mapper接口

```java
public interface DemoMapper {
    /**
     * 执行 hello 方法时候, MyBatis会自动执行
     * 查询语句, 并且SQL查询结果作为方法返回结果
     * @return Hello World!
     */
    @Select("SELECT 'Hello World!'")
    String hello();
}
```

测试类

```java
@SpringBootTest
@Slf4j
class Mybatis1ApplicationTests {
    @Resource
    private DemoMapper demoMapper;
    @Test
    void contextLoads() {
        String str = demoMapper.hello();
        log.debug(str);
    }
}
```

## 数据库CRUD

### 创建 表

```sql
CREATE DATABASE demo;
USE demo;
CREATE TABLE emp(
    EMPNO int(4) NOT NULL AUTO_INCREMENT,
    ENAME varchar(10),
    JOB varchar(9),
    MGR int(4),
    HIREdate date,
    SAL double(7,2),
    COMM double(7,2),
    DEPTNO int(4),
    PRIMARY KEY (EMPNO)
);
INSERT INTO emp
    (EMPNO, ENAME, JOB, MGR, HIREdate, SAL, COMM, DEPTNO)
    values
    (null, 'Tom', 'Coding', 0, now(), 1000.0, 100.0, 1);
```

修改数据库连接URL

```
jdbc:mysql://localhost:3306/demo?characterEncoding=utf8&useSSL=false&serverTimezone=Asia/Shanghai&rewriteBatchedStatements=true
```

### 查询功能

步骤:

1. 创建实体类

   ```java
   
   /**
    * 员工类
    */
   @Data
   @Accessors(chain = true)
   public class Employee implements Serializable {
       private Integer empNo;
       private String name;
       private String job;
       private Integer mgr;
       //Java 8 提供的日期类型 LocalDate
       private LocalDate hiredate;
       private Double salary;
       private Double comm;
       private Integer deptNo;
   }
   ```

2. 声明访问接口

   ```java
   /**
    * Employee 的数据访问接口
    */
   public interface EmployeeMapper {
       /**
        * 根据ID查询一个员工数据
        * #{empNo} 是MyBatis的参数占位符,
        * 在查询时候, MyBatis会读取方法参数
        * 作为占位的参数传输到数据库执行SQL
        *
        * 如果查询结果中的列名和实体类属性不
        * 一致, 可以使用设置列别名方式, 将查询
        * 结果列与实体类的属性名对应上
        */
       //@Select("SELECT * FROM emp WHERE EMPNO=#{empNo}")
       @Select({"SELECT ",
               "empNo," ,
               "ename AS name," ,
               "job,",
               "mgr, ",
               "hiredate, ",
               "sal AS salary,",
               "comm,",
               "deptNo",
               "FROM emp WHERE EMPNO=#{empNo}"})
       Employee getEmployeeById(Integer empNo);
   }
   ```

3. 测试:

   ```java
   @SpringBootTest
   @Slf4j
   public class EmployeeMapperTests {
   
       @Resource
       EmployeeMapper mapper;
   
       @Test
       void getEmployeeById(){
           Employee employee = mapper.getEmployeeById(1);
           log.debug("{}", employee);
       }
   }
   ```

### 插入数据功能

1. 声明Mapper接口方法

   ```java
    /**
        * 利用MyBatis将员工数据插入到数据中
        * INSERT INTO emp
        *     (EMPNO, ENAME, JOB, MGR, HIREdate, SAL, COMM, DEPTNO)
        *     VALUES
        *     (null, 'Tom', 'Coding', 0, now(), 1000.0, 100.0, 1)
        *
        * 参数: #{name}表示读取employee对象的name属性
        */
       @Insert({"INSERT INTO emp",
               "(EMPNO, ENAME, JOB, MGR, HIREdate, SAL, COMM, DEPTNO)",
               "VALUES",
               "(null, #{name}, #{job}, #{mgr}, #{hiredate},",
               "#{salary}, #{comm}, #{deptNo})"})
       /**
        * Options: 选项
        * Generated: 生成的
        * Keys: 关键字
        * keyProperty: 关键字属性, 就是实体类中的ID
        * 标注了@Options()可以与 @Insert配合获取自动生成的 Key
        * keyProperty = "empNo" 中的empNo是Employee的属性
        */
       @Options(useGeneratedKeys = true, keyProperty = "empNo")
       Integer saveEmployee(Employee employee);
   ```

2. 测试:

   ```java
   @Test
   void saveEmployee(){
       //由于是添加新员工, 不用写员工号
       Employee employee = new Employee().setName("Jerry")
               .setJob("玩猫")
               .setDeptNo(1)
               .setComm(100.0)
               .setSalary(2000.0)
               .setHiredate(LocalDate.now())
               .setMgr(0);
       /**
        * saveEmployee返回值表示添加到数据库中的数量
        */
       Integer n = mapper.saveEmployee(employee);
       log.debug("添加数:{}", n);
   }
   ```

### 修改数据功能

1. Mapper接口:

   ```java
   /**
    * 根据ID更新一个员工的全部信息
    * UPDATE emp
    * SET ENAME=?, JOB=?, MGR=?, HIREdate=?,
    *     SAL=?, COMM=?, DEPTNO=?
    * WHERE EMPNO=?;
    * MyBatis的Mapper方法, 如果执行的是
    * INSERT UPDATE DELETE 则可以返回一个
    * 整数结果, 表示插入\更新\删除的行数
    */
   @Update({"UPDATE emp",
           "SET ENAME=#{name}, JOB=#{job}, MGR=#{mgr}, HIREdate=#{hiredate},",
           "    SAL=#{salary}, COMM=#{comm}, DEPTNO=#{deptNo}",
           "WHERE EMPNO=#{empNo}"})
   Integer updateEmployee(Employee employee);
   ```

2. 测试

   ```java
   @Test
   void updateEmployee(){
       /**
        * 测试更新员工信息
        */
       Employee employee = new Employee().setEmpNo(2)
               .setName("Jerry")
               .setJob("学习")
               .setDeptNo(2)
               .setComm(10.0)
               .setSalary(20000.0)
               .setHiredate(LocalDate.now())
               .setMgr(0);
       Integer n = mapper.updateEmployee(employee);
       log.debug("更新了:{}", n);
   }
   ```

### 删除功能

1. mapper接口

   ```java
   /**
    * 删除 一行 数据
    * DELETE FROM emp WHERE EMPNO=?
    */
   @Delete("DELETE FROM emp WHERE EMPNO=#{empNo}")
   Integer deleteEmployeeById(Integer empNo);
   ```

2. 测试

   ```java
   @Test
   void deleteEmployeeById(){
       Integer n=mapper.deleteEmployeeById(2);
       log.debug("删除:{}", n);
   }
   ```

### 查询返回多个结果

1. Mapper接口方法

   ```java
   /**
    * 将全部的员工信息查询出来
    */
   @Select({"SELECT ",
           "empNo," ,
           "ename AS name," ,
           "job,",
           "mgr, ",
           "hiredate, ",
           "sal AS salary,",
           "comm,",
           "deptNo",
           "FROM emp"})
   List<Employee> getAllEmployee();
   ```

2. 测试:

   ```java
   @Test
   void getAllEmployee(){
       List<Employee> employees
               = mapper.getAllEmployee();
       employees.forEach(e->log.debug("{}", e));
   }
   ```

###  多参数查询

```java
/**
 * 查询 薪资介于2000到2200之间的员工
 * X BETWEEN A AND B : X 介于 A 和 B 之间
 * SELECT * FROM emp WHERE SAL BETWEEN 2000 AND 2200
 */
/**
 * 关于参数名称:
 * 1. Java 8 之前Java编译以后, 在字节码文件中不保留
 *    方法参数变量名. 为了处理对个参数变量, MyBatis
 *    提供了一个注解, @Param("min") 作用就是给参数
 *    方法参数变量一个名称, 用于SQL语句参数绑定
 * 2. Java 8 以后SpringBoot在Maven插件中开启保留
 *    Java方法参数名到字节码文件的功能. Java 8 +
 *    SpringBoot 时候, 可以不用使用@Param("min")
 * 3. 利用阿里云脚手架创建的SpringBoot项目, 没有
 *    打开这个开关, 按照1进行编译.
 */
@Select({"SELECT ",
        "empNo," ,
        "ename AS name," ,
        "job,",
        "mgr, ",
        "hiredate, ",
        "sal AS salary,",
        "comm,",
        "deptNo",
        "FROM emp",
        "WHERE SAL BETWEEN #{min} AND #{max}",
        "ORDER BY SAL DESC"})
List<Employee> getEmployeeBySalary(
        @Param("min") Double min, 
    	@Param("max") Double max);
```

2. 测试

   ```java
   @Test
   void getEmployeeBySalary(){
       List<Employee> employees =
               mapper.getEmployeeBySalary(2000.0, 2200.0);
       employees.forEach(
           employee -> log.debug("{}", employee));
   }
   ```