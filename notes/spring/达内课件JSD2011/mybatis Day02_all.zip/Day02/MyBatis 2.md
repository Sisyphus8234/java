

# MyBatis 2

## 复杂SQL映射

 MyBatis 的复杂的SQL映射关系, 需要使用XML映射文件实现. 

使用步骤:

1. 声明Mapper接口方法
2. 创建Mapper接口对应的XML
   1. 创建位置 resources/mappers/
   2. namespace 对应接口名
   3. sql语句的ID与接口方法名对应
3. 在application.properties文件中配置 XML文件位置

使用XML映射:

```java
/**
* 测试利用XML文件将SQL映射到demo方法
* @return
*/
String demo();
```
 映射文件

```xml
<?xml version="1.0" encoding="UTF-8" ?>
<!DOCTYPE mapper
  PUBLIC "-//mybatis.org//DTD Mapper 3.0//EN"
  "http://mybatis.org/dtd/mybatis-3-mapper.dtd">
<!-- MyBatis 利用namespace 属性找到XML文件对应的Mapper接口-->
<mapper namespace="cn.tedu.mybatis1.mapper.DemoMapper">
    <!-- MyBatis 根据id属性值找到接口中对应的方法名-->
    <!--
    select 元素, 必须指定resultMap或者resultType属性
    用于将SQL查询结果映射到返回值类型, resultMap用于
    复杂返回结果映射, resultType 适合简单类型, 或者
    简单JavaBean的映射. 使用resultType时候, 设定返回值
    类型即可.
     -->
    <select id="demo" resultType="java.lang.String" >
        SELECT 'Hello World!'
    </select>
</mapper>
```

测试:

```java
@Test
void demo(){
    String str = demoMapper.demo();
    log.debug(str);
}
```



## 变长参数

调用方法时候可以传达 0~n个参数

```java
add();
add(2);
add(2,3);
add(3,4,5);
add(3,4,5,8);
add(...);
```

利用重载只能解决一定数量的可变参数, 处理不了无限参数. Java 5 开始提供可变参数功能, 可变参数的本质是数组参数. 

```java
//定义可变参数
add(int... n)
```

- 语法: 类型... 变量名
- 调用时候, 可以写 0~n个参数
- 在方法内部 可变参数就是数组!
- 语法限制:
  - 参数类型一致
  - 一个方法只能有一个可变参数, 只能定义在最后一个参数

案例

```java
public class ParamDemo {
    public static void main(String[] args) {
        System.out.println(add()); //add({})
        System.out.println(add(1));//add({1})
        System.out.println(add(2,3));//add({2,3})
        System.out.println(add(3,4,5));//add({3,4,5})
    }
    public static int add(int... n){
        int sum = 0;
        for(int i : n){
            sum += i;
        }
        return sum;
    }
}
```

### 复杂SQL删除多个数据

![image-20210312120410129](image-20210312120410129.png)

如: 使用一个SQL删除一组数据.

```SQL
DELETE FROM emp WHERE empno IN (3,4,5,6,7)
```

定义Mapper方法

```java
Integer deleteAllEmployees(Integer... empNumbers)
```

利用XML映射SQL

```xml
<!-- delete 不用定义返回值类型 -->
<!-- foreach 用于将参数数组\集合遍历拼接动态SQL 
     collection 如果参数是一个数组则取值是 array
     collection 如果参数是一个List集合则取值是 list
	 collection 如果参数是多个参数, 则取值是参数名称
	 collection 如果遍参数的属性, 则取值是 对象.属性
     item 是遍历时候每个元素的值
	 separator 拼接字符串时候的分隔符
	 for 循环中使用 	#{id} 读取循环变量
    -->
<!-- 最终拼接结果
     DELETE FROM emp WHERE empno IN (3,4,5,6,7) -->
<delete id="deleteAllEmployees">
	DELETE FROM emp 
    WHERE empno 
    IN (
    <foreach collection="array" item="id" separator=",">
        #{id} 
    </foreach>
    )
</delete>
```

测试:

```java
@Test
void deleteAllEmployees(){
    Integer n = mapper.deleteAllEmployees(4,5,7);
    log.debug("{}", n);
}
```

### 使用 ${} 拼接SQL

- ${} 将Mapper方法的参数, 作为SQL语句的一部分拼接到SQL中 
- #{}  将Mapper方法的参数, 作为SQL语句的参数使用

例子:

```java
String getName(String columnName, Integer param)
```

调用参数:

```java
mapper.getName("ename", 3);
```

映射SQL

```SQL
SELECT ${columnName} FROM emp WHERE id = #{param}
```

生成的SQL

```sql
SELECT ename FROM emp WHERE id = ?
```

面试题目: MyBatis中 ${} 和 #{} 的区别?

- ${} 用于SQL语句拼接, 可以直接改变SQL, 有SQL注入风险
- #{} 用于传输SQL参数, 只能作为SQL语句参数, 没有SQL注入风险

### `<if>` 动态拼接

语法

```xml
<if test="表达式">
  拼接内容
</if>
```

如果表达式成立, 就将拼接内容连接到SQL语句中, 如果表达式不成立, 则不拼接内容.

例子:

```XML
UPDATE SET
<if test="job != null">
  job = #{job}
</if>
WHERE empNo=#{empNo}
```

完整的案例:

```java
/**
 * 删除一组员工对象
 */
Integer deleteAllEmployees(Integer... empNumbers);
```

```xml
<delete id="deleteAllEmployees">
    DELETE FROM emp
    WHERE EMPNO IN (
        <foreach collection="array" item="id" separator=",">
            #{id}
        </foreach>
    )
</delete>
```

测试

```java
@Test
void deleteAllEmployees(){
    Integer n = mapper.deleteAllEmployees(4,5,7);
    log.debug("{}", n);
}
```


设计Mapper接口方法:

```java
Integer updateEmployeeInfo(Employee employee);
```

调用方法:

```java
Employee employee = new Employee().setEmpNo(3)
    .setJob("Study");
```

映射SQL:

```xml
<update id="updateEmployeeInfo">
    UPDATE emp
    <set>
    	<if test="name != null">
            ename=#{name},
        </if>       
    	<if test="job != null">
            job=#{job}
        </if>
    </set>
    WHERE empNo = #{empNo}
</update>
```

映射SQL时候, `<set>` 可以自动去除多余 符号

多路分支(双路分支): 如下语法, 

- 条件1成立,就将SQL1拼接到SQL;
- 条件2成立,就将SQL2拼接到SQL; 
- 条件都不成立,就将SQL3拼接到SQL;
- 如果只有一个when和一个otherwise就是双路分支;
- when 可以写多个, 就是多路分支

```xml
<choose>
    <when test="条件1">
        //SQL1...
    </when>
    <when test="条件2">
        //SQL2...
    </when>
    <otherwise>
        //SQL3...
    </otherwise>
</choose>
```

案例:

```java
    /**
     * 动态更新属性方法, 可以更改部分属性值
     * 参数中必须设定 empNo 属性
     * 设置需要更改的属性值, 不需要更改的保存null
     * 更新时候, 会自动将不为空的属性值更新到数据库
     */
    Integer updateEmployeeInfo(Employee employee);
```

```xml

    <update id="updateEmployeeInfo">
        UPDATE emp
        <set>
            <if test="name != null">
                ename=#{name} ,
            </if>
            <if test="job != null">
                job=#{job} ,
            </if>
            <if test="hiredate != null">
                hiredate=#{hiredate} ,
            </if>
            <if test="mgr != null">
                mgr=#{mgr} ,
            </if>
            <if test="salary != null">
                sal=#{salary} ,
            </if>
            <if test="comm != null">
                comm=#{comm} ,
            </if>
            <if test="deptNo != null">
                deptNo=#{deptNo}
            </if>
        </set>
        <if test="empNo != null">
            WHERE empNo = #{empNo}
        </if>
    </update>
```

### 关联查询

![image-20210312172806482](image-20210312172806482.png)

增加一个表演示关联查询:

```sql
CREATE TABLE dept(
    DEPTNO INT(6) NOT NULL AUTO_INCREMENT,
    DNAME VARCHAR(20),
    LOCATION VARCHAR(100),
    PRIMARY KEY (DEPTNO)
);
INSERT INTO dept (DEPTNO, DNAME, LOCATION)
    VALUES (null, 'Java', '北京');
INSERT INTO dept (DEPTNO, DNAME, LOCATION)
    VALUES (null, 'C++', '天坛');
```

执行如下关联查询:

```SQL
SELECT EMPNO, ENAME, DNAME 
FROM emp e 
    LEFT JOIN dept d on e.DEPTNO = d.DEPTNO
WHERE DNAME='Java'
```

得到可能结果:

| EMPNO | ENAME | DNAME |
| ----- | ----- | ----- |
| 1     | Tom   | Java  |
| 6     | Wang  | Java  |
| 8     | 熊大  | Java  |

定义值对象, 封装查询结果: 

### 值对象与 实体对象

- 值对象(Value Object), 用于封装数据, 与数据库中的数据不是一一对象的, 用于临时性封装一组数据, 如: 从数据查询得到的结果.

- 实体对象(Entity Object), 用于封装数据, 实现对象与数据库中的行一一对象, 用于配合持久层进行进行数据的操作. 一个表对应一个实体类.

```java

/**
 * 值对象, 用于封装数据库查询结果
 */
@Data
@Accessors(chain = true)
public class EmployeeVO {
    /** 员工号 */
    private Integer empNo;
    /** 员工名 */
    private String name;
    /** 部门名 */
    private String department;
}
```

```java

    /**
     * SELECT EMPNO, ENAME, DNAME
     * FROM emp e
     *     LEFT JOIN dept d on e.DEPTNO = d.DEPTNO
     * WHERE DNAME='Java'
     * 利用值对象封装关联查询结果, 值对象就是为了针对当前查询
     * 定义的对象, 专门封装当前查询的返回值
     * @return
     */
    @Select({"SELECT ",
            "EMPNO, ",
            "ENAME AS name, ",
            "DNAME AS department",
            "FROM emp e",
            "LEFT JOIN dept d on e.DEPTNO = d.DEPTNO",
            "WHERE DNAME=#{dname}"})
    List<EmployeeVO> getEmployeeInfo(String dname);
```

```java
@Test
void getEmployeeInfo(){
    List<EmployeeVO> list = mapper.getEmployeeInfo("Java");
    list.forEach(employeeVO -> log.debug("{}", employeeVO));
}
```









