package cn.tedu.mybatis1.vo;

import lombok.Data;
import lombok.experimental.Accessors;

/**
 * 值对象, 用于封装数据库查询结果
 */
@Data
@Accessors(chain = true)
public class EmployeeVO {
    /** 员工号 */
    private Integer empNo;
    /** 员工名 */
    private String name;
    /** 部门名 */
    private String department;
}
