package cn.tedu.mybatis1.mapper;

import org.apache.ibatis.annotations.Select;

public interface DemoMapper {
    /**
     * 执行 hello 方法时候, MyBatis会自动执行
     * 查询语句, 并且SQL查询结果作为方法返回结果
     * @return Hello World!
     */
    @Select("SELECT 'Hello World!'")
    String hello();

    /**
     * 测试利用XML文件将SQL映射到demo方法
     * @return
     */
    String demo();
}
