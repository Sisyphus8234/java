package cn.tedu.mybatis1;

import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * @MapperScan 是MyBatis提供的注解, 标注在
 * Spring配置类上, Spring启动时候就会自动扫描
 * 指定包和子包, 将实现包中的Mapper接口, 并且
 * 创建Mapper接口的匿名实现类.
 */
@SpringBootApplication
@MapperScan("cn.tedu.mybatis1.mapper")
public class Mybatis1Application {

    public static void main(String[] args) {
        SpringApplication.run(Mybatis1Application.class, args);
    }

}
