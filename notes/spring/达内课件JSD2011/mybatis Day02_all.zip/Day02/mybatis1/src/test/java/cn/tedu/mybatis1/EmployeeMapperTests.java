package cn.tedu.mybatis1;

import cn.tedu.mybatis1.entity.Employee;
import cn.tedu.mybatis1.mapper.EmployeeMapper;
import cn.tedu.mybatis1.vo.EmployeeVO;
import lombok.extern.slf4j.Slf4j;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

import javax.annotation.Resource;
import java.time.LocalDate;
import java.util.List;

@SpringBootTest
@Slf4j
public class EmployeeMapperTests {

    @Resource
    EmployeeMapper mapper;

    @Test
    void getEmployeeById(){
        Employee employee = mapper.getEmployeeById(1);
        log.debug("{}", employee);
    }
    @Test
    void getAllEmployee(){
        List<Employee> employees
                = mapper.getAllEmployee();
        employees.forEach(e->log.debug("{}", e));
    }

    @Test
    void saveEmployee(){
        //由于是添加新员工, 不用写员工号
        Employee employee = new Employee().setName("Jerry")
                .setJob("玩猫")
                .setDeptNo(1)
                .setComm(100.0)
                .setSalary(2000.0)
                .setHiredate(LocalDate.now())
                .setMgr(0);
        /**
         * saveEmployee返回值表示添加到数据库中的数量
         */
        Integer n = mapper.saveEmployee(employee);
        log.debug("添加数:{}", n);
    }

    @Test
    void updateEmployee(){
        /**
         * 测试更新员工信息
         */
        Employee employee = new Employee().setEmpNo(2)
                .setName("Jerry")
                .setJob("学习")
                .setDeptNo(2)
                .setComm(10.0)
                .setSalary(20000.0)
                .setHiredate(LocalDate.now())
                .setMgr(0);
        Integer n = mapper.updateEmployee(employee);
        log.debug("更新了:{}", n);
    }

    @Test
    void deleteEmployeeById(){
        Integer n=mapper.deleteEmployeeById(2);
        log.debug("删除:{}", n);
    }

    /**
     * 准备数据
     * 插入数据, 为了方便后续测试
     */
    @Test
    void addData(){
        Employee employee = new Employee().setName("Jerry")
                .setJob("玩猫").setDeptNo(1).setComm(100.0)
                .setSalary(2000.0).setHiredate(LocalDate.now()).setMgr(0);
        Integer n = mapper.saveEmployee(employee);
        employee = new Employee().setName("熊大")
                .setJob("打光头强").setDeptNo(1).setComm(10.0)
                .setSalary(1000.0).setHiredate(LocalDate.now()).setMgr(0);
        n = mapper.saveEmployee(employee);
        employee = new Employee().setName("熊二")
                .setJob("打光头强").setDeptNo(1).setComm(5.0)
                .setSalary(1100.0).setHiredate(LocalDate.now()).setMgr(0);
        n = mapper.saveEmployee(employee);
        employee = new Employee().setName("光头强")
                .setJob("砍树").setDeptNo(1).setComm(10.0)
                .setSalary(2100.0).setHiredate(LocalDate.now()).setMgr(0);
        n = mapper.saveEmployee(employee);
        employee = new Employee().setName("蜘蛛侠")
                .setJob("侠客").setDeptNo(1).setComm(51.0)
                .setSalary(2200.0).setHiredate(LocalDate.now()).setMgr(0);
        n = mapper.saveEmployee(employee);

    }

    @Test
    void getEmployeeBySalary(){
        List<Employee> employees =
                mapper.getEmployeeBySalary(2000.0, 2200.0);
        employees.forEach(employee -> log.debug("{}", employee));
    }

    @Test
    void saveAuto(){
        //由于是添加新员工, 不用写员工号
        Employee employee = new Employee().setName("李靖")
                .setJob("古玩").setDeptNo(1).setComm(10.0)
                .setSalary(2900.0).setHiredate(LocalDate.now())
                .setMgr(0);
        /**
         * saveEmployee返回值表示添加到数据库中的数量
         */
        Integer n = mapper.saveEmployee(employee);
        log.debug("添加数:{}", n);
        log.debug("添加成功:{}", employee);
    }

    @Test
    void deleteAllEmployees(){
        Integer n = mapper.deleteAllEmployees(4,5,7);
        log.debug("{}", n);
    }

    @Test
    void getName(){
        String s = mapper.getName("ename", 3);
        log.debug("{}",s);
        String s2 = mapper.getName("job", 3);
        log.debug("{}",s2);
    }

    @Test
    void updateEmployeeInfo(){
        Employee employee = new Employee()
                .setEmpNo(3)
                .setName("Wang");
        Integer n = mapper.updateEmployeeInfo(employee);
        log.debug("{}", n);
    }

    @Test
    void getEmployeeInfo(){
        List<EmployeeVO> list = mapper.getEmployeeInfo("Java");
        list.forEach(employeeVO -> log.debug("{}", employeeVO));
    }
}
