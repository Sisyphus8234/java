package cn.tedu.mybatis1;

public class ParamDemo {
    public static void main(String[] args) {
        System.out.println(add()); //add({})
        System.out.println(add(1));//add({1})
        System.out.println(add(2,3));//add({2,3})
        System.out.println(add(3,4,5));//add({3,4,5})
    }
    public static int add(int... n){
        int sum = 0;
        for(int i : n){
            sum += i;
        }
        return sum;
    }
}
