package cn.tedu.spring1;

public class DemoBean {
    @Override
    public String toString() {
        return "Hello World!";
    }
}
