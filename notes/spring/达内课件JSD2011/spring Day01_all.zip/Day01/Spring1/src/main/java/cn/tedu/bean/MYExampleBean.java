package cn.tedu.bean;

import org.springframework.stereotype.Component;

@Component
public class MYExampleBean {
    @Override
    public String toString() {
        return "MYExampleBean";
    }
}
