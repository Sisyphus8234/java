package cn.tedu.bean;

import org.springframework.stereotype.Component;

@Component("test")
public class HelloBean {
    @Override
    public String toString() {
        return "HelloBean";
    }
}
