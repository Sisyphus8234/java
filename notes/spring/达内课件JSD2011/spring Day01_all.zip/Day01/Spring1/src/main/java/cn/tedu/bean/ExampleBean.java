package cn.tedu.bean;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.stereotype.Service;

@Component
public class ExampleBean {
    @Override
    public String toString() {
        return "ExampleBean";
    }
}
