package cn.tedu;

import cn.tedu.config.Config;
import cn.tedu.spring1.DemoBean;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class Test {
    public static void main(String[] args) {
        /**
         * 测试Spring可以创建管理对象(IoC)
         * Annotation : 注解
         * Config : 配置
         * Application: 应用程序
         * Context: 上下文
         * 注解配置应用程序上下文 == Spring
         * 创建 AnnotationConfigApplicationContext 对象时候,
         * 必须提供配置类的类名 Config.class!
         */
        AnnotationConfigApplicationContext ctx =
                new AnnotationConfigApplicationContext(Config.class);
        //Spring 提供了一个getBean方法, 参数是类型, 返回值是Spring
        //创建的对象, 如果前述配置的DemoBean
        //DemoBean bean = ctx.getBean(DemoBean.class);
        //检查对象. 输出bean, 输出时候自动调用 toString()
        //System.out.println(bean);
        //如有HelloWorld就证明 Spring 管理创建了DemoBean对象

        //当按照类型获取对象有冲突时候, 就可以按照对象的ID获取对象
        //默认情况下, 对象ID就是配置文件中创建对象的方法名
        //getBean方法根据对象的ID获取对象, 参数是对象的ID,
        //如果对象ID错误, 抛出异常!
        DemoBean demoBean = ctx.getBean("demoBean1", DemoBean.class);
        System.out.println(demoBean);
    }
}
