package comb;

public class test2 {

    public String f(){

        return "123";
    }
}
