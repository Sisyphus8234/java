package xxxgroupId.xxxSpringBoot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class XxxSpringBootApplication {

	public static void main(String[] args) {
		SpringApplication.run(XxxSpringBootApplication.class, args);
	}

}
