package xxxgroupId.xxxSpringBoot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class XxxSpringBootApplicationTests {

	@Test
	void contextLoads() {
	}

}
