package cn.tedu.work.controller;

import cn.tedu.work.entity.User;
import cn.tedu.work.mapper.UserMapper;
import cn.tedu.work.vo.JsonResult;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

import javax.annotation.Resource;

@RestController
public class UserController {

    @Resource
    private UserMapper userMapper;

    @PostMapping("/handle_update")
    public JsonResult update(User user){
        try{
            int num=userMapper.updateUserInfo(user);
            System.out.println(num);
            return new JsonResult(1,"修改成功!");
        }catch (Exception e){
            e.printStackTrace();
            return new JsonResult(0,"修改失败");
        }


    }



}
