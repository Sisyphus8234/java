package cn.tedu.work.mapper;

import cn.tedu.work.entity.User;

public interface UserMapper {

    Integer updateUserInfo(User user);

}
