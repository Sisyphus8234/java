package cn.tedu.work.vo;

import java.io.Serializable;

public class JsonResult implements Serializable {

    private Integer state;
    private String message;

    public JsonResult(){}

    public JsonResult(Integer state, String message) {
        this.state = state;
        this.message = message;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }
}
