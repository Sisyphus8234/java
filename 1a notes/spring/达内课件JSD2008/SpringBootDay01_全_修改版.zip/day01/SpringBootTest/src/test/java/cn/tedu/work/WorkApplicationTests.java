package cn.tedu.work;

import cn.tedu.work.entity.User;
import cn.tedu.work.mapper.UserMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class WorkApplicationTests {

    @Autowired(required = false)
    private UserMapper userMapper;
    @Test
    void contextLoads() {
        User u=new User();
        u.setId(18);
        u.setAge(30);
        Integer num=userMapper.updateUserInfo(u);
        System.out.println(num);
    }

}
