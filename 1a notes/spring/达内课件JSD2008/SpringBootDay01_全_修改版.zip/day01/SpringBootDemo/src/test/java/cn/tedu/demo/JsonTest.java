package cn.tedu.demo;

import cn.tedu.demo.vo.JsonResult;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
public class JsonTest {

    @Test
    public void testJson() throws JsonProcessingException {
        JsonResult result=new JsonResult(
                500,"服务器内部错误!");
        //Jackson 提供的API能够将java对象转换为json格式的字符串
        ObjectMapper mapper=new ObjectMapper();
        //执行转换
        String json=mapper.writerWithDefaultPrettyPrinter()
                .writeValueAsString(result);
        System.out.println(json);

    }



}
