package cn.tedu.demo;

import cn.tedu.demo.entity.User;
import cn.tedu.demo.mapper.UserMapper;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.context.SpringBootTest;

import javax.annotation.Resource;
import javax.sql.DataSource;
import java.sql.SQLException;

@SpringBootTest
class DemoApplicationTests {

    @Autowired
    private DataSource dataSource;

    @Test
    void contextLoads() throws SQLException {
        System.out.println(dataSource.getConnection());
    }

    //@Autowired(required = false)
    @Resource
    private UserMapper mapper;
    @Test
    void addNewUser(){
        User u=new User(null,"zhangfei",
                "777",27,"13017777715",
                "feifei@163.com");
        int num=mapper.addUser(u);
        System.out.println(num);
        System.out.println(u.getId());
    }

    @Test
    void testUpdate(){
        User u=new User();
        u.setId(18);
        u.setUsername("张翼德");
        int num=mapper.updateUserInfo(u);
        System.out.println(num);
    }





}
