package cn.tedu.demo.controller;

import cn.tedu.demo.vo.JsonResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class DemoController {

    @GetMapping("/hello")
    public String hello(){
        return "Hello SpringBoot!";
    }


    @GetMapping("/ajax")
    public JsonResult ajax(){
        return new JsonResult(500,"服务器内部错误");
    }


}
