package cn.tedu.demo.mapper;

import cn.tedu.demo.entity.User;
import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

public interface UserMapper {

    @Insert("insert into t_user(username,password,age,phone,email)" +
            "values(#{username},#{password},#{age},#{phone},#{email})")
    @Options(useGeneratedKeys = true,keyProperty = "id")
    Integer addUser(User user);



    Integer updateUserInfo(User user);

    //按用户名查询用户
    @Select("select * from t_user where username=#{username}")
    User getUserByUsername(String username);







}
