package cn.tedu.demo.vo;

public class JsonResult {

    private Integer state;
    private String message;
    //{state:500,message:"服务器内部错误"}
    public  JsonResult(){}

    public JsonResult(Integer state, String message) {
        this.state = state;
        this.message = message;
    }

    public Integer getState() {
        return state;
    }

    public void setState(Integer state) {
        this.state = state;
    }

    public String getMessage() {
        return message;
    }

    public void setMessage(String message) {
        this.message = message;
    }

    @Override
    public String toString() {
        return "JsonResult{" +
                "state=" + state +
                ", message='" + message + '\'' +
                '}';
    }
}
