package cn.tedu.demo.controller;

import cn.tedu.demo.entity.User;
import cn.tedu.demo.mapper.UserMapper;
import cn.tedu.demo.vo.JsonResult;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class UserController {

    //  这里仅仅为了测试功能,暂时允许直接调用mapper
    @Autowired(required = false)
    private UserMapper userMapper;

    @PostMapping("/handle_reg")
    public JsonResult handleReg(User user){
        try{
            //先检查这个用户的用户名是否存在
            User u=userMapper.getUserByUsername(user.getUsername());
            //判断u是不是null,如果是null表示没有这个用户名,反之不能注册
            if(u!=null){
                return new JsonResult(-1,"用户名已被占用");
            }
            int num=userMapper.addUser(user);
            if(num==1){
                return  new JsonResult(1,"注册成功");
            }else{
                return  new JsonResult(0,"注册失败");
            }
        }catch (Exception e){
            e.printStackTrace();
            return new JsonResult(0,"注册失败");
        }
    }


    /*@PostMapping("/handle_reg")
    public String handleReg(User user){
        try{
            userMapper.addUser(user);
            return "注册成功!";
        }catch(Exception e){
            e.printStackTrace();
            return e.getMessage();
        }
    }*/
}
