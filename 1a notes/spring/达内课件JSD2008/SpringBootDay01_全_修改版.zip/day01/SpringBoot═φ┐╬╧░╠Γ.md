SpringBoot晚课习题

使用tedu_ums数据库的t_user数据库操作

1.新建一个SpringBoot项目名称自拟

2.application.properties配置当前项目 数据源\端口号\log4j\mapper的xml文件位置

3.新建User实体类,对应t_user表

4.新建页面,页面上有表单,表单中可以填写如下信息  id,age,phone

5.页面上编写代码发送ajax请求,执行修改操作,修改指定id的age或phone

6.ajax请求的结果显示在页面的指定位置比如执行修改后显示"修改成功"或"修改失败"

7.编写mapper接口,xml实现动态查询,并使用SpringBootTest测试

8.编写控制器类,接收ajax发送的请求,调用mapper的修改方法,将结果发送给ajax