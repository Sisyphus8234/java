CREATE TABLE t_department (
 	id INT(11) AUTO_INCREMENT COMMENT '部门ID',
 	name VARCHAR(20) NOT NULL COMMENT '部门名',
 	PRIMARY KEY (id)
)DEFAULT CHARSET=UTF8;

INSERT INTO t_department (NAME) 
VALUES ('Java'), ('C++'), ('Linux');

alter table t_user add column department_id int

UPDATE t_user SET department_id=1 WHERE id<=7

UPDATE t_user SET department_id=2 WHERE id>7

-- 建立外键关系
ALTER TABLE t_user
ADD CONSTRAINT dept_user FOREIGN KEY (department_id)
REFERENCES t_department(id)
修改表 t_user
增加约束   dept_user  外键约束 (department_id)
引用  t_department(id)

关联查询的sql语句
SELECT u.id,username,d.name
 FROM t_user u
 LEFT JOIN  t_department d
 ON u.department_id=d.id










