package cn.tedu.config;

import cn.tedu.entity.Department;
import cn.tedu.entity.User;
import cn.tedu.mapper.DemoMapper;
import cn.tedu.mapper.DepartmentMapper;
import cn.tedu.mapper.UserMapper;
import cn.tedu.vo.UserVO;
import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;

public class TestXml {

    AnnotationConfigApplicationContext ctx;
    @Before
    public void init(){
        ctx=new AnnotationConfigApplicationContext(
                MyBatisConfig.class);
    }
    @After
    public void destroy(){
        ctx.close();
    }

    @Test
    public void testHelloXml(){
        UserMapper mapper=ctx.getBean(
                "userMapper",UserMapper.class);
        String username=mapper.getUsernameById();
        System.out.println(username);
    }

    @Test
    public  void testForeachDelete(){
        UserMapper userMapper=ctx.getBean(
                "userMapper",UserMapper.class);
        Integer num=userMapper.deleteById(1,3,5);
        System.out.println(num);

    }

    @Test
    public void testUpdate(){
        UserMapper mapper=ctx.getBean(
                "userMapper",UserMapper.class);
        User user=new User();
        user.setId(10);
        //user.setEmail("frank02@qq.com");
        //user.setAge(28);
        user.setPassword("4321");
        user.setPhone("18055500555");
        Integer num=mapper.updateUserInfo(user);
        System.out.println(num);
    }


    @Test
    public void testSelect(){
        UserMapper mapper=ctx.getBean(
                "userMapper",UserMapper.class);
        List<User> list=mapper.findUsersByParam(
                "F%",null,"13%");
        for(User u: list){
            System.out.println(u);
        }

    }

    // 关联查询(值对象)
    @Test
    public  void  getUserVO(){
        UserMapper mapper=ctx.getBean(
                "userMapper",UserMapper.class);
        List<UserVO> list=mapper.findUserDepartment();
        for(UserVO vo :list){
            System.out.println(vo);
        }

    }

    //关联查询(映射集合)
    @Test
    public void selectList(){
        DepartmentMapper mapper=ctx.getBean(
                "departmentMapper",DepartmentMapper.class);
        Department d=mapper.findDeptWithUserById(1);
        System.out.println(d);
    }




}
