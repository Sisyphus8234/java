package cn.tedu.config;

import cn.tedu.entity.User;
import cn.tedu.mapper.DemoMapper;
import cn.tedu.mapper.UserMapper;
import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.List;

public class TestMybatis {

    AnnotationConfigApplicationContext ctx;
    @Before
    public void init(){
        ctx=new AnnotationConfigApplicationContext(
                MyBatisConfig.class);
    }
    @After
    public void destroy(){
        ctx.close();
    }

    @Test
    public void selectId(){
        UserMapper mapper=ctx.getBean(
                "userMapper", UserMapper.class);
        User user=mapper.findUserById(1);
        System.out.println(user);

    }

    @Test
    public void selectAll(){
        UserMapper mapper=ctx.getBean(
                "userMapper",UserMapper.class);
        List<User> list=mapper.findAllUsers();
        for (User u:list) {
            System.out.println(u);
        }
    }


    @Test
    public void insert(){
        User user=new User(null,"Tom","123",
                28,"13811012345","tom@tedu.cn");
        UserMapper mapper=ctx.getBean(
                "userMapper",UserMapper.class);
        Integer num=mapper.insertUser(user);
        System.out.println(num);

    }

    @Test
    public void insertWithId(){
        User user=new User(null,"Jerry","456",
                21,"13811013789","jerry@tedu.cn");
        UserMapper mapper=ctx.getBean(
                "userMapper",UserMapper.class);
        Integer num=mapper.insertUserWithId(user);
        System.out.println(num);
        System.out.println(user);

    }

    @Test
    public void updateUser(){
        User user=new User(16,"LiLei","888",25,
                "13812345678","lilei@qq.com");
        UserMapper mapper=ctx.getBean(
                "userMapper",UserMapper.class);
        Integer num=mapper.updateUser(user);
        System.out.println(num);
    }

    @Test
    public void updateEmail(){
        Integer id=14;
        String email="tom@sina.com";
        UserMapper userMapper=ctx.getBean(
                "userMapper",UserMapper.class);
        Integer num=userMapper.updateEmailById(id,email);
        System.out.println(num);
    }

    @Test
    public void deleteById(){
        UserMapper mapper=ctx.getBean(
                "userMapper",UserMapper.class);
        Integer num=mapper.deleteById(14);
        System.out.println(num);
    }

    @Test
    public void likename(){
        UserMapper mapper=ctx.getBean(
                "userMapper",UserMapper.class);
        List<User> users=mapper.getUsersLikeName("L%");
        for(User u: users){
            System.out.println(u);
        }
    }










}
