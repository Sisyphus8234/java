package cn.tedu.config;

import cn.tedu.mapper.DemoMapper;
import org.apache.ibatis.session.SqlSessionFactory;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;

public class TestCase {

    AnnotationConfigApplicationContext ctx;
    @Before
    public void innt(){
        ctx=new AnnotationConfigApplicationContext(
                MyBatisConfig.class);
    }
    @After
    public void destroy(){
        ctx.close();
    }

    @Test
    public void testDataSource(){
        DataSource ds=ctx.getBean(
                "dataSource",DataSource.class);
        String sql="select username from vrduser where id=1";
        try(Connection conn=ds.getConnection()){
            Statement st=conn.createStatement();
            ResultSet rs=st.executeQuery(sql);
            while(rs.next()){
                System.out.println(rs.getString(1));
            }
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    @Test
    public void testFactory(){
        SqlSessionFactory factory=ctx.getBean(
                "sqlSessionFactory",SqlSessionFactory.class);
        System.out.println(factory);
    }
    //执行Mapper接口中的方法
    @Test
    public void testUsername(){
        DemoMapper mapper=ctx.getBean(
                "demoMapper",DemoMapper.class);
        String name=mapper.hello();
        System.out.println(name);
    }








}
