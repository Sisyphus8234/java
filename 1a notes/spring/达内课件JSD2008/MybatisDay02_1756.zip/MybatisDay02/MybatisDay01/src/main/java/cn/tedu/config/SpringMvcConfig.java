package cn.tedu.config;

import org.springframework.context.annotation.ComponentScan;

@ComponentScan("cn.tedu")
public class SpringMvcConfig {



}
