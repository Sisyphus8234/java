package cn.tedu.mapper;

import cn.tedu.entity.Department;

public interface DepartmentMapper {

    //按id查询部门以及部门员工的信息
    Department findDeptWithUserById(Integer id);
}
