package cn.tedu.test;

public class Number {
    //可变参数方法的定义
    //在参数列表中参数类型后加...表示这个参数是可变参数
    //1.一个方法只能有一个可变参数,而且必须是这个方法的最后一个参数
    //2.在方法内部处理这个参数时,将这个参数视为一个数组
    public static void  sum(int... nums){
        //假设这个方法的业务是计算所有参数之和
        int sum=0;
        for(int i=0;i<nums.length;i++){
            sum+=nums[i];
        }
        System.out.println(sum);
    }

    public static void main(String[] args) {
        //可变参数方法调用事项
        //1.可变参数的数量可以是0个,1个或多个
        //2.可变参数的位置可以传入该类型的数组
        sum();
        sum(100);
        sum(8,10,20);
        int[] a={5,9,1,2,4,2,3,7};
        sum(a);


    }



}
