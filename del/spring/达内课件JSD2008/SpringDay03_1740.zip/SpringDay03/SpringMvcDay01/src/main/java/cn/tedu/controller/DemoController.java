package cn.tedu.controller;

import org.springframework.stereotype.Component;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import java.sql.SQLOutput;

//使用@Controller注解这个类
//能够将这个类注入到Spring容器的同时还能表明它是一个控制器
@Controller
public class DemoController {

    // 编写@GetMapping注解来规定什么请求能够访问这个方法
    // 我们配置了只有.do结尾的请求能够进入SpringMvc所以这里的路径必须以.do结尾
    @GetMapping("/hello.do")
    // 我们由于没有具体页面可以显示，所以需要添加下面的注解
    // 表示当前请求的结果就是在浏览器上显示返回的字符串
    @ResponseBody
    public String demo(){
        System.out.println("demo运行");
        return "Hello SpringMvc";
    }

    @GetMapping("/test.do")
    public ModelAndView test(){
        System.out.println("运行了test");
        //返回的hello会被模板引擎自动添加配置好的前缀和后缀
        //resources/templates/hello.html
        return new ModelAndView("hello");
    }
    //代码已上传!






}
