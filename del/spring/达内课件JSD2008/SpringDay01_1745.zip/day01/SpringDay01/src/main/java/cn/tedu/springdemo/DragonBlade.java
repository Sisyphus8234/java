package cn.tedu.springdemo;

import org.springframework.context.annotation.Lazy;
import org.springframework.stereotype.Component;

@Component("db")
//@Scope("prototype")
@Lazy
public class DragonBlade {

    private String name="青龙偃月刀";

    @Override
    public String toString() {
        return "DragonBlade{" +
                "name='" + name + '\'' +
                '}';
    }
}
