package cn.tedu.write;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;

@ComponentScan("cn.tedu.write")
public class Config {

    @Bean
    public Person ming(){
        Person person=new Person();
        person.setName("小明");
        return person;
    }

}
