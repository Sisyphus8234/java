package cn.tedu.write;

public class Person {

    private String name;
    private Pen pen;

    public void write(){
        System.out.println(name+"使用"+pen+"写字");
    }


    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Pen getPen() {
        return pen;
    }

    public void setPen(Pen pen) {
        this.pen = pen;
    }

}
