package cn.tedu.hero;

import org.springframework.stereotype.Component;

@Component("lancer")
public class SkyLancer {

    private String name="方天画戟";

    @Override
    public String toString() {
        return name;
    }
}
