package cn.tedu.springdemo;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Lazy;

//Spring框架的配置类

//组件扫描注解:
//@ComponentScan规定这个配置类需要扫描哪个包中的类
@ComponentScan("cn.tedu.springdemo")
public class Config {

    /**
     * @Bean 注解的方法:
     * 表示这个方法的返回值会注入到Spring容器中
     * 注入的对象,可以在该方法中创建并赋值
     * 这个方法的方法名默认情况下是这个对象的ID(名字)
     * @return
     */
    @Bean("caocao")
    //@Scope("prototype")
    @Lazy
    public Stu student(){
        Stu stu=new Stu();
        stu.setName("曹操");
        stu.setAge(60);
        return stu;
    }

    //这个方法注入了青龙偃月刀没有任何属性赋值
    //代码比较冗余
    //推荐使用组件扫描
//    @Bean
//    public DragonBlade blade(){
//        return new DragonBlade();
//    }





}
