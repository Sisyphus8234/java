package cn.tedu.hero;

import org.springframework.stereotype.Component;

@Component("blade")
public class DragonBlade {

    private String name="青龙偃月刀";

    @Override
    public String toString() {
        return name;
    }
}
