package cn.tedu.hero;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Import;
import org.springframework.context.annotation.Scope;

@ComponentScan("cn.tedu.hero")
@Import({Config2.class})
public class Config {


    @Bean
    @Scope("prototype")
    //@Lazy
    public Hero guanYu(){
        Hero h=new Hero();
        h.setName("关羽");
        h.setPower(97);
        return h;
    }

}
