package cn.tedu.write;

import org.springframework.stereotype.Component;

@Component
public class Pen {

    private String name="钢笔";

    @Override
    public String toString() {
        return name;
    }
}
