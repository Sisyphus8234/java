package cn.tedu.springdemo;

import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class SpringTest {

    public static void main(String[] args) {
        //想启用Spring还需要依据我们编写的Spring配置类来创建对象
        AnnotationConfigApplicationContext ctx=
                new AnnotationConfigApplicationContext(Config.class);
        //实例化上面对象参数是配置类的反射
        //原因是反射中包含这个类中所有内容的信息,方便Spring处理

        //将对象从Spring容器中获取
        //现在用两个参数,第一个参数是获取对象的id
        //第二个参数是获取对象的类型
        Stu caocao=ctx.getBean("student",Stu.class);
        //输出这个对象
        System.out.println(caocao);

        ctx.close();

    }
}
