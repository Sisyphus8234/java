package cn.tedu.hero;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Lazy;

public class Config2 {
    @Bean
    @Lazy
    public Hero lvBu(){
        Hero h=new Hero();
        h.setName("吕布");
        h.setPower(100);
        return h;
    }
}
