package cn.tedu.write;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class WriteTest {

    AnnotationConfigApplicationContext ctx;
    //@Before注解的方法会在具体测试代码运行之前运行
    @Before
    public void init(){
        ctx=new AnnotationConfigApplicationContext(Config.class);
        System.out.println("Before");
    }
    //@After注解的方法会在具体测试代码运行之后运行
    @After
    public void destroy(){
        ctx.close();
        System.out.println("After");
    }

    @Test
    public void test(){
        Person p=ctx.getBean("ming",Person.class);
        Pen pen=ctx.getBean("pen",Pen.class);
        p.setPen(pen);
        p.write();
    }









}
