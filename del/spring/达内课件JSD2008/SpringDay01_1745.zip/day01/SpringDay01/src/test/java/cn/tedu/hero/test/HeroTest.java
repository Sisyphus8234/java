package cn.tedu.hero.test;

import cn.tedu.hero.Config;
import cn.tedu.hero.DragonBlade;
import cn.tedu.hero.Hero;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

public class HeroTest {

    AnnotationConfigApplicationContext ctx;

    @Before
    public void init(){
        ctx=new AnnotationConfigApplicationContext(Config.class);
        System.out.println("11111111111");
    }
    @After
    public void destroy(){
        ctx.close();
    }

    @Test
    public void weapon(){
        DragonBlade db=ctx.getBean("blade",DragonBlade.class);
        System.out.println(db);

    }



    @Test
    public void test(){
        System.out.println("222222222222");
        Hero gy=ctx.getBean("guanYu",Hero.class);
        System.out.println(gy);
        System.out.println("333333333333");
        Hero gyc=ctx.getBean("guanYu",Hero.class);
        System.out.println(gyc);
        System.out.println(gy==gyc);


        Hero lb=ctx.getBean("lvBu",Hero.class);
        System.out.println(lb);

    }


    @Test
    public void fightTest(){

//        Hero hero=ctx.getBean("lvBu",Hero.class);
//        SkyLancer lancer=ctx.getBean("lancer",SkyLancer.class);
//        hero.setSkyLancer(lancer);
//        hero.zhanDou();


        Hero h=ctx.getBean("guanYu",Hero.class);
        DragonBlade db=ctx.getBean("blade",DragonBlade.class);
        h.setDragonBlade(db);
        h.fight();


    }






}
