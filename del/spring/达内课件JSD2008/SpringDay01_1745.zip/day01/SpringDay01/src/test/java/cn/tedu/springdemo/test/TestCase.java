package cn.tedu.springdemo.test;

import cn.tedu.springdemo.Config;
import cn.tedu.springdemo.DragonBlade;
import cn.tedu.springdemo.Stu;
import org.junit.After;
import org.junit.Before;
import org.junit.Test;
import org.springframework.context.annotation.AnnotationConfigApplicationContext;

//这是一个测试类
//类名是随意的
public class TestCase {

    AnnotationConfigApplicationContext ctx;
    //@Before注解的方法会在具体测试代码运行之前运行
    @Before
    public void init(){
        ctx=new AnnotationConfigApplicationContext(Config.class);
        System.out.println("Before");
    }
    //@After注解的方法会在具体测试代码运行之后运行
    @After
    public void destroy(){
        ctx.close();
        System.out.println("After");
    }


    //要想可以测试,编写一个注解
    //@Test标注的方法就是一个可以进行测试的方法
    @Test
    public void test(){
        System.out.println("hello");
    }

    //一个测试类中可以编写多个测试方法
    @Test
    public void springTest(){
//        AnnotationConfigApplicationContext ctx=
//                new AnnotationConfigApplicationContext(Config.class);
        Stu caocao=ctx.getBean("caocao",Stu.class);
        System.out.println(caocao);
//        ctx.close();
    }

    @Test
    public void testBlade(){
        DragonBlade blade=ctx.getBean("db",DragonBlade.class);
        System.out.println(blade);
    }

    @Test
    public void singleton(){

        System.out.println("----1111111------");
        Stu caocao=ctx.getBean("caocao",Stu.class);
        System.out.println(caocao);
        //caocao.setAge(61);

        System.out.println("----2222222------");
        Stu cao=ctx.getBean("caocao",Stu.class);
        System.out.println(cao);

    }





}
